// ZIP extraction is bounded and only accepts one PDF with a matching CRC.
importScripts('issuer-archive.js');
// Side panel controls all MST credential synchronization through client-side AES-GCM.
// Mở side panel khi bấm icon; ghi file qua chrome.downloads.
// Check all issuer host permissions automatically at startup, silently.
 // Chrome grants manifest-required domains at installation unless the user
 // subsequently restricts them in browser settings. Never prompt/auto-request.
 async function verifyIssuerPermissions(){
  try{
   const required=(chrome.runtime.getManifest().host_permissions||[])
    .filter(origin=>!origin.includes('supabase.co'));
   const result=await chrome.permissions.getAll();
   const granted=new Set(result.origins||[]);
   const missing=required.filter(origin=>!granted.has(origin));
   await chrome.storage.session.set({autotax_demo_issuer_access:{
    checkedAt:Date.now(),checked:required.length,allowed:required.length-missing.length,
    missing:missing.length
   }});
  }catch(error){
   // Diagnostic only; PDF fetch will handle per-domain failures normally.
   console.warn('[AutoTax DEMO] Background issuer access audit unavailable.');
  }
 }
 void verifyIssuerPermissions();
 chrome.runtime.onInstalled.addListener(()=>void verifyIssuerPermissions());
 chrome.permissions.onAdded.addListener(()=>void verifyIssuerPermissions());
 chrome.permissions.onRemoved.addListener(()=>void verifyIssuerPermissions());

// Global panel, never tab-specific: persists across tab switches.
function configureGlobalSidePanel(){
 chrome.sidePanel.setOptions({path:'index.html',enabled:true}).catch(e=>
  console.warn('[AutoTax] Cannot set global panel:',e.message));
 chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
}
configureGlobalSidePanel();
chrome.runtime.onInstalled.addListener(configureGlobalSidePanel);
chrome.runtime.onStartup.addListener(configureGlobalSidePanel);
/* Global sidePanel options are persistent. Reapplying setOptions() on every
   tab activation can remount the panel and make it look as if it reloaded.
   Configure only at service-worker startup / extension installation. */


// Chỉ báo thành công khi Chrome xác nhận tệp đã tải xong, không phải chỉ mới nhận lệnh.
function waitForDownload(id) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      clearTimeout(timer);
      chrome.downloads.onChanged.removeListener(onChanged);
    };
    const finish = (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      error ? reject(new Error(error)) : resolve({ id, complete: true });
    };
    const onChanged = (delta) => {
      if (delta.id !== id) return;
      if (delta.state?.current === 'complete') finish();
      else if (delta.state?.current === 'interrupted') finish(delta.error?.current || 'Tải xuống bị gián đoạn.');
    };
    const timer = setTimeout(() => finish('Quá thời gian chờ Chrome hoàn tất tải xuống.'), 10 * 60 * 1000);
    chrome.downloads.onChanged.addListener(onChanged);
    // Kiểm tra trạng thái hiện tại để tránh bỏ lỡ sự kiện complete đến trước khi listener kịp xử lý.
    chrome.downloads.search({ id }, (items) => {
      if (chrome.runtime.lastError) return finish(chrome.runtime.lastError.message);
      const item = items?.[0];
      if (!item) return finish('Không tìm thấy tác vụ tải xuống trong Chrome.');
      if (item.state === 'complete') finish();
      else if (item.state === 'interrupted') finish(item.error || 'Tải xuống bị gián đoạn.');
    });
  });
}

// Provider PDF retrieval is strictly opt-in and domain-scoped. Never proxy
// arbitrary URLs, attach browser cookies, follow redirects, or mislabel HTML as PDF.
// Only approved consumer invoice domains from AutoTax's 21-provider catalog.
const ISSUER_DOMAINS=new Set([
 'meinvoice.vn','fpt.com.vn','kiotviet.vn','vnpt-invoice.com.vn',
 'ehoadon.vn','easyinvoice.vn','minvoice.com.vn','thaison.vn',
 'mobifone.vn','fast.com.vn','nacencomm.vn','hilo.com.vn',
 'matbao.in','vinvoice.vn','viettel.vn','smartsign.com.vn',
 'xuathoadon.vn','cloudinvoice.vn','vietinvoice.vn','oinvoice.vn',
 'ehoadon.online'
]);
const approvedIssuerHost=host=>[...ISSUER_DOMAINS].some(domain=>
 host===domain||host.endsWith('.'+domain));
function issuerPdfURL(value){
 let u;
 try{u=new URL(String(value||''))}catch{throw Error('Đường dẫn PDF không hợp lệ.')}
 if(u.protocol!=='https:'||u.username||u.password||
    (u.port&&u.port!=='443')||!approvedIssuerHost(u.hostname.toLowerCase()))
  throw Error('Nhà phát hành chưa nằm trong danh sách miền được phép.');
 if(!/(?:\.(?:pdf|zip)$|\/pdf(?:\/|$)|\/(?:download|export)(?:\/|$|[^/]*)|(?:format|type)=(?:pdf|zip))/i.test(u.pathname+u.search))
  throw Error('Đây là trang tra cứu, chưa phải liên kết tải PDF trực tiếp.');
 return u;
}
async function fetchIssuerPdf(value,authenticated=false){
 const u=issuerPdfURL(value);
 // All issuer domains are declared as required host permissions in V1.1.
 // Authentication is used ONLY after an explicit click in the real issuer tab.
 // Default automated requests never attach login cookies or security codes.
 const res=await fetch(u.href,{method:'GET',credentials:authenticated?'include':'omit',redirect:'error',cache:'no-store',
  signal:AbortSignal.timeout(20000),headers:{Accept:'application/pdf,application/octet-stream'}});
 if(!res.ok)throw Error('Máy chủ nhà phát hành trả HTTP '+res.status);
 // Provider ZIPs (e.g. KiotViet) may contain both the original PDF and XML.
 const cap=24*1024*1024,n=Number(res.headers.get('content-length')||0);
 if(n>cap)throw Error('Tệp PDF/ZIP lớn hơn 24 MB.');
 const pieces=[];let size=0;
 if(res.body){
  const reader=res.body.getReader();
  for(;;){
   const {value,done}=await reader.read();if(done)break;
   size+=value.byteLength;
   if(size>cap){await reader.cancel();throw Error('Tệp PDF/ZIP lớn hơn 24 MB.')}
   pieces.push(value);
  }
 }else{
  const data=new Uint8Array(await res.arrayBuffer());size=data.byteLength;
  if(size>cap)throw Error('Tệp PDF/ZIP lớn hơn 24 MB.');pieces.push(data);
 }
 const data=new Uint8Array(size);let offset=0;
 for(const part of pieces){data.set(part,offset);offset+=part.byteLength}
 const isPdf=data.length>=5&&data[0]===37&&data[1]===80&&
   data[2]===68&&data[3]===70&&data[4]===45;
 const isZip=data.length>=4&&data[0]===80&&data[1]===75&&
   data[2]===3&&data[3]===4;
 let pdf=data,sourceType='pdf';
 if(isZip){
  const result=await globalThis.AutoTaxIssuerArchive.extractPdf(data);
  pdf=result.pdf;sourceType='zip';
 }else if(!isPdf){
  throw Error('Cổng nhà phát hành chưa trả PDF/ZIP thực (có thể cần CAPTCHA, phiên đăng nhập hoặc nút Tải xuống).');
 }
 if(pdf.byteLength>12*1024*1024)throw Error('PDF gốc lớn hơn 12 MB.');
 let chars='';
 for(let i=0;i<pdf.length;i+=8192)
  chars+=String.fromCharCode(...pdf.subarray(i,i+8192));
 return {ok:true,pdfBase64:btoa(chars),origin:u.hostname,sourceType};
}

// V1.1 assisted retrieval: the issuer's own CAPTCHA/authentication happens in
// its real page. Only the user can start a lookup and authorize PDF capture.
// Never persist PDF bytes or tax passwords; session queue expires after 2h.
const ISSUER_QUEUE='autotax_issuer_lookup_queue_v11';
const ISSUER_TTL=2*60*60*1000;
const issuerGroup=host=>[...ISSUER_DOMAINS].find(domain=>
 host===domain||host.endsWith('.'+domain));
function lookupURL(value){
 const u=new URL(String(value||''));
 if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||
  !issuerGroup(u.hostname.toLowerCase()))throw Error('Link không thuộc 21 cổng nhà phát hành được duyệt.');
 return u;
}
async function issuerQueue(){
 const a=(await chrome.storage.session.get(ISSUER_QUEUE))[ISSUER_QUEUE];
 return (Array.isArray(a)?a:[]).filter(x=>x.addedAt>Date.now()-ISSUER_TTL).slice(-100);
}
async function issuerAdd(record,sender){
 if(!String(sender?.url||'').startsWith(chrome.runtime.getURL('index.html')))
  throw Error('Chỉ trang Thuế đã đăng nhập được thêm link tra cứu hóa đơn.');
 const u=lookupURL(record?.link),code=String(record?.code||'').trim();
 if(!code||code.length>300||u.href.length>2048)throw Error('Thiếu mã hoặc link tra cứu hợp lệ.');
 const invoice=String(record?.invoice||'').replace(/[^0-9A-Za-z_.-]/g,'_').slice(0,90);
 const ownerMst=String(record?.ownerMst||'').replace(/\D/g,'');
 if(!/^(?:\d{10}|\d{12}|\d{13})$/.test(ownerMst))
  throw Error('Hồ sơ MST không hợp lệ.');
 const sellerMst=String(record?.sellerMst||'').replace(/\D/g,'').slice(0,13);
 const buyerMst=String(record?.buyerMst||'').replace(/\D/g,'').slice(0,13);
 const invoiceNumber=String(record?.invoiceNumber||'').replace(/[^0-9A-Za-z-]/g,'').slice(0,40);
 const key=[ownerMst,u.hostname,invoice,code].join('|');
 const a=await issuerQueue();
 if(!a.some(x=>x.key===key))a.push({
  key,link:u.href,code,invoice,ownerMst,sellerMst,buyerMst,invoiceNumber,
  addedAt:Date.now(),opened:false
 });
 await chrome.storage.session.set({[ISSUER_QUEUE]:a.slice(-100)});
 return {ok:true,count:a.length};
}
async function issuerOpenNext(owner){
 const ownerMst=String(owner||'').replace(/\D/g,'');
 const all=await issuerQueue();
 const visible=all.filter(x=>x.ownerMst===ownerMst);
 const item=visible.find(x=>!x.opened)||visible[0];
 if(!item)return {ok:false,error:'Chưa có hóa đơn cần mở. Hãy bật PDF gốc và tải hóa đơn trên cổng Thuế trước.'};
 // Set the session BEFORE navigating; content scripts can run very early.
 const tab=await chrome.tabs.create({url:'about:blank',active:true});
 try{
  await chrome.storage.session.set({['autotax_issuer_tab_'+tab.id]:{...item,tabId:tab.id,
    monitorDownloads:true}});
  await chrome.tabs.update(tab.id,{url:item.link});
 }catch(e){
  await chrome.storage.session.remove('autotax_issuer_tab_'+tab.id);
  await chrome.tabs.remove(tab.id).catch(()=>{});
  throw e;
 }
 item.opened=true;
 await chrome.storage.session.set({[ISSUER_QUEUE]:all});
 return {ok:true,tabId:tab.id,invoice:item.invoice,count:all.length};
}
async function issuerSession(sender){
 const tabId=sender?.tab?.id;
 if(!Number.isInteger(tabId))throw Error('Yêu cầu cần xuất phát từ trang nhà phát hành.');
 const item=(await chrome.storage.session.get('autotax_issuer_tab_'+tabId))
  ['autotax_issuer_tab_'+tabId];
 if(!item||Date.now()-item.addedAt>ISSUER_TTL)throw Error('Phiên tra cứu đã hết hạn.');
 const current=lookupURL(sender?.url),initial=lookupURL(item.link);
 if(issuerGroup(current.hostname)!==issuerGroup(initial.hostname))
  throw Error('Trang hiện tại không cùng nhà phát hành với hóa đơn.');
 return item;
}
async function issuerDownloadFromPage(message,sender){
 const item=await issuerSession(sender);
 const candidate=issuerPdfURL(message?.url);
 if(issuerGroup(candidate.hostname)!==issuerGroup(new URL(item.link).hostname))
  throw Error('PDF phải cùng nhà phát hành của hóa đơn.');
 const pdf=await fetchIssuerPdf(candidate.href,true);
 const safeInvoice=(item.invoice||'HoaDon').replace(/[^0-9A-Za-z_.-]/g,'_');
 const filename='Hoa Don/'+item.ownerMst+'/pdf_goc/'+safeInvoice+'.pdf';
 const downloadId=await chrome.downloads.download({
  url:'data:application/pdf;base64,'+pdf.pdfBase64,filename,
  conflictAction:'uniquify',saveAs:false
 });
 await waitForDownload(downloadId);
 const list=await issuerQueue();
 await chrome.storage.session.set({[ISSUER_QUEUE]:list.filter(x=>x.key!==item.key)});
 await chrome.storage.session.remove('autotax_issuer_tab_'+item.tabId);
 return {ok:true,filename,remaining:Math.max(0,list.length-1),
  note:'Đã tải PDF thực. Chữ ký và nội dung hóa đơn cần được đối chiếu riêng.'};
}

// The issuer may download a file only after a slider CAPTCHA/lookup, often via
// a JavaScript button rather than a direct <a href>. Chrome can route that
// browser-initiated download without guessing private supplier APIs.
// This does NOT inspect the final file's signature or turn a ZIP into a PDF.
chrome.downloads.onDeterminingFilename.addListener((item,suggest)=>{
 if(!Number.isInteger(item?.tabId))return;
 const done=(filename)=>filename?suggest({filename,conflictAction:'uniquify'}):suggest();
 (async()=>{
  const data=await chrome.storage.session.get('autotax_issuer_tab_'+item.tabId);
  const record=data['autotax_issuer_tab_'+item.tabId];
  if(!record?.monitorDownloads||Date.now()-record.addedAt>ISSUER_TTL)return done();
  const candidate=String(item.finalUrl||item.url||'');
  let u;try{u=new URL(candidate)}catch{return done()}
  let hostname='';
  if(u.protocol==='https:')hostname=u.hostname;
  else if(u.protocol==='blob:'){
   try{hostname=new URL(u.pathname).hostname}catch{return done()}
  }else return done();
  const initial=new URL(record.link);
  if(issuerGroup(hostname.toLowerCase())!==issuerGroup(initial.hostname.toLowerCase()))
   return done();
  const originalName=String(item.filename||'').split('/').pop().split(String.fromCharCode(92)).pop();
  const mime=String(item.mime||'').toLowerCase();
  const ext=/\.pdf$/i.test(originalName)||mime==='application/pdf'?'pdf':
    /\.zip$/i.test(originalName)||/zip|compressed/.test(mime)?'zip':'';
  if(!ext)return done();
  const basename=String(record.invoice||'HoaDon').replace(/[^0-9a-zA-Z_.-]/g,'_').slice(0,100);
  const sub=ext==='pdf'?'PDF_Goc_Nha_Phat_Hanh':'ZIP_Nha_Phat_Hanh';
  // Only this one user-opened supplier tab is affected; all other downloads
  // remain untouched. A ZIP stays a ZIP until its PDF content is verified.
  return done('Hoa Don/'+record.ownerMst+'/'+sub+'/'+basename+'.'+ext);
 })().catch(()=>done());
 return true;
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if(msg?.type==='issuer-queue-add'){
    issuerAdd(msg,sender).then(reply,e=>reply({ok:false,error:e.message}));
    return true;
  }
  if(msg?.type==='issuer-queue-count'){
    issuerQueue().then(a=>reply({ok:true,
      count:a.filter(x=>x.ownerMst===String(msg.ownerMst||'').replace(/\D/g,'')).length}),
      e=>reply({ok:false,error:e.message}));
    return true;
  }
  if(msg?.type==='issuer-open-next'){
    if(!sender?.url?.startsWith(chrome.runtime.getURL('index.html')))
      return reply({ok:false,error:'Chỉ Add-on mới mở phiên tra cứu.'}),false;
    issuerOpenNext(msg.ownerMst).then(reply,e=>reply({ok:false,error:e.message}));
    return true;
  }
  if(msg?.type==='issuer-assist-state'){
    issuerSession(sender).then(item=>reply({ok:true,invoice:item.invoice,
      code:item.code,sellerMst:item.sellerMst,buyerMst:item.buyerMst,
      invoiceNumber:item.invoiceNumber}),
      e=>reply({ok:false,error:e.message}));
    return true;
  }
  if(msg?.type==='issuer-assist-download'){
    issuerDownloadFromPage(msg,sender).then(reply,e=>reply({ok:false,error:e.message}));
    return true;
  }

  if(msg.type==='stock-tab-update-catalog'){
   (async()=>{
    const tabId=msg.portalTabId,requestId=String(msg.requestId||'');
    if(!Number.isInteger(tabId)||!/^tendoo-map-[a-zA-Z0-9.-]+$/.test(requestId))
     throw Error('Phiên ánh xạ không hợp lệ.');
    if(!String(sender?.url||'').startsWith(chrome.runtime.getURL('tendoo-match.html')))
     throw Error('Chỉ trang ánh xạ AutoTax được cập nhật SKU.');
    const key='autotax-tendoo-request-'+requestId;
    const payload=(await chrome.storage.session.get(key))[key];
    if(!payload||payload.portalTabId!==tabId)throw Error('Phiên ánh xạ hết hạn.');
    if(!Array.isArray(msg.products)||!msg.products.length||msg.products.length>25000||
       msg.products.some(x=>!x||typeof x.sku!=='string'||typeof x.name!=='string')||
       JSON.stringify(msg.products).length>7500000)
     throw Error('Danh mục SKU không hợp lệ hoặc quá lớn.');
    const name=String(msg.filename||'').slice(0,180);
    const result=await chrome.runtime.sendMessage({
     type:'demo-native-stock-catalog',requestId,filename:name,products:msg.products
    });
    if(!result?.ok)throw Error(result?.error||'Side Panel chưa nhận danh mục.');
    payload.products=msg.products;
    await chrome.storage.session.set({[key]:payload});
    return {ok:true,count:msg.products.length};
   })().then(reply,error=>reply({ok:false,error:error.message}));
   return true;
  }
  if (msg.type === 'stock-tab-mapping') {
    (async()=>{
      const tabId=msg.portalTabId,requestId=String(msg.requestId||'');
      if(!Number.isInteger(tabId)||!/^tendoo-map-[a-zA-Z0-9.-]+$/.test(requestId))
        throw Error('Phiên liên kết không hợp lệ.');
      const key='autotax-tendoo-request-'+requestId;
      const payload=(await chrome.storage.session.get(key))[key];
      if(!payload||payload.portalTabId!==tabId)
        throw Error('Phiên ánh xạ đã hết hạn hoặc trang Thuế đã thay đổi.');
      const validKeys=new Set(payload.names.map(n=>n.key));
      const validCodes=new Set(payload.products.map(p=>p.sku));
      for(const [name,sku] of Object.entries(msg.mapping||{})){
        if(!validKeys.has(name)||!validCodes.has(sku))
          throw Error('Tên sản phẩm hoặc mã SKU không hợp lệ.');
      }
      if(!String(sender?.url||'').startsWith(chrome.runtime.getURL('tendoo-match.html')))
        throw Error('Chỉ trang ánh xạ của tiện ích được phép gửi dữ liệu.');
      // Forward from the separate SKU mapping tab to the native Side Panel.
      const result=await chrome.runtime.sendMessage({
        type:'demo-native-mapping',requestId,mapping:msg.mapping||{}
      });
      if(!result?.ok)throw Error('Chưa có tác vụ nhập kho đang chờ trong Add-on.');
      await chrome.storage.session.remove(key);
      return {ok:true};
    })().then(reply,e=>reply({ok:false,error:e.message}));
    return true;
  }
  if (msg.type === 'fetch-issuer-pdf') {
    fetchIssuerPdf(msg.url).then(reply,e=>reply({ok:false,error:e.message||String(e)}));
    return true;
  }
  if (msg.type === 'download') {
    // Always hand Chrome an explicit safe filename. This prevents data/blob
    // downloads from falling back to the browser's generic "download" name.
    const rawName=String(msg.filename||'').replace(/\\/g,'/').replace(/^\/+|\/+$/g,'');
    const safeName=(rawName||('AutoTax_'+Date.now()+'.bin'))
      .split('/').filter(Boolean).map(part=>part.replace(/[<>:"|?*\x00-\x1f]/g,'_').slice(0,120)).join('/');
    // Tải lại cùng hóa đơn thì ghi đè, không sinh file trùng.
    chrome.downloads.download({ url: msg.url, filename: safeName, conflictAction: 'overwrite', saveAs: false })
      // Chrome owns this download after it is queued. Never block the invoice
      // export for up to ten minutes waiting for the final onChanged event.
      .then(id=>reply({id,accepted:true,complete:false}))
      .catch(e=>reply({error:e.message}));
    return true;
  }
});
