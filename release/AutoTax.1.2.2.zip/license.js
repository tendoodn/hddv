(() => {
 const BASE='https://ucqqjdsoyvvaxswzbhaw.supabase.co',KEY='sb_publishable_7zUjUap6EkHJZ0Gp12vesw_UY-yB7jJ',STORE='autotax_license_session_v1',SYNC='autotax_auth_sync_v1';
 let session=null,license=null,timer=null,checking=false,packages=[],trialActivationConfirmed=false,profileMsts=[],profileAllowedMsts=[],profileNames={};
 let renderedPackagesFingerprint=null,invoiceQuotaPopupUser='',sharedInvoiceMsts=[],sharedProfileMsts=[];
 const showInvoiceQuotaPopup=()=>{const dialog=$('lic-invoice-limit-dialog');if(dialog&&!dialog.open)dialog.showModal()};
 const LOGIN_PREF_KEY='autotax-remembered-login-v113';
 const migratedLegacyMst=new Set();
 async function migratePreviousMstPasswords(msts){
  const owner=session?.user?.id;
  if(!owner||!await window.AutoTaxSharedMstVault?.unlocked())return;
  // Migration is non-destructive and never overwrites existing encrypted cloud data.
  for(const mst of msts){
   if(session?.user?.id!==owner)break;
   const id=owner+':'+mst;
   if(migratedLegacyMst.has(id))continue;
   try{
    const password=await globalThis.DemoSecureStorage.getItem('gdt:'+id);
    if(password)await window.AutoTaxSharedMstVault.importLocal(mst,password);
    migratedLegacyMst.add(id);
   }catch(e){console.warn('MST legacy sync pending for '+mst+':',e.message)}
  }
 }
 window.AutoTaxSharedMstVault?.setAuthProvider(async()=>{
  if(session?.expires_at&&session.expires_at*1000<Date.now()+30000)
   await refreshToken();
  return {userId:session?.user?.id,token:session?.access_token};
 });
 async function rememberLogin(email,password){
  // Encrypt credentials in device-local IndexedDB, never in cleartext chrome.storage.
  await globalThis.DemoSecureStorage.setItem(LOGIN_PREF_KEY,JSON.stringify({email,password}));
 }
 async function restoreLogin(){
  try{const raw=await globalThis.DemoSecureStorage.getItem(LOGIN_PREF_KEY);
   if(!raw)return;
   const data=JSON.parse(raw);
   if(data?.email&&!$('lic-email').value)$('lic-email').value=data.email;
   if(data?.password&&!$('lic-password').value)$('lic-password').value=data.password;
  }catch(error){console.warn('Không khôi phục được tài khoản đã nhớ:',error.message)}
 }
 const $=id=>document.getElementById(id),emit=()=>document.dispatchEvent(new CustomEvent('autotax-license-change',{detail:{license,session}}));
 const headers=token=>({apikey:KEY,'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})});
 async function request(path,options={},token=session?.access_token){const res=await fetch(BASE+path,{...options,headers:{...headers(token),...(options.headers||{})}});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.msg||data.message||data.error_description||data.error||'Máy chủ trả về lỗi '+res.status);return data}
 const emitProfiles=()=>document.dispatchEvent(new CustomEvent('autotax-mst-profiles',{
  detail:{msts:[...profileMsts],allowed:[...profileAllowedMsts],labels:{...profileNames},userId:session?.user?.id||null}
 }));
 const save=()=>{const syncedAt=Date.now();return chrome.storage.local.set({
  [STORE]:session,
  [SYNC]:{state:session?'signed_in':'signed_out',session:session||null,syncedAt}
 })};
 let tokenRefreshInFlight=null;
 // Sessions survive Side Panel closing/reopening. Never erase them on a
 // network timeout: only explicit logout clears local credentials.
 async function refreshToken(){
  if(!session?.refresh_token)return false;
  if(tokenRefreshInFlight)return tokenRefreshInFlight;
  const previous=session;
  tokenRefreshInFlight=(async()=>{
   try{
    const renewed=await request('/auth/v1/token?grant_type=refresh_token',{
     method:'POST',body:JSON.stringify({refresh_token:previous.refresh_token}),
     signal:AbortSignal.timeout(12000)
    },null);
    if(!renewed?.access_token||!renewed?.refresh_token||session?.user?.id!==previous.user?.id)return false;
    session={...previous,...renewed,user:renewed.user||previous.user};
    await save();
    emit();
    return true;
   }catch(error){
    // Concurrent panels may rotate a token. Prefer the newer stored session.
    try{
     const latest=(await chrome.storage.local.get(STORE))[STORE];
     if(latest?.refresh_token&&latest.refresh_token!==previous.refresh_token&&
        latest.user?.id===previous.user?.id&&session?.user?.id===previous.user?.id){
      session=latest;emit();return true;
     }
    }catch{}
    console.warn('Chưa làm mới được phiên AutoTax; vẫn giữ đăng nhập đã lưu:',error.message||error);
    return false;
   }
  })();
  try{return await tokenRefreshInFlight}finally{tokenRefreshInFlight=null}
 }
 async function authed(path,options={}){
  if(!session?.access_token)throw new Error('Vui lòng đăng nhập.');
  if(session.expires_at&&session.expires_at*1000<Date.now()+30000&&!(await refreshToken()))
   throw new Error('Chưa làm mới được phiên AutoTax. Kiểm tra mạng rồi thử lại; tài khoản vẫn được ghi nhớ.');
  try{return await request(path,options)}
  catch(error){
   if(!/401|JWT|token|unauthorized/i.test(error.message)||!(await refreshToken()))throw error;
   return request(path,options);
  }
 }
 const rpc=(name,args={})=>authed('/rest/v1/rpc/'+name,{method:'POST',body:JSON.stringify(args)});
 function message(t,error=false){const el=$('lic-message');el.textContent=t;el.className='lic-message'+(error?' error':'');el.hidden=!t}
 function gate(){document.dispatchEvent(new CustomEvent('autotax-license-gate',{detail:{allowed:!!license?.allowed}}))}
 function money(v){return Number(v||0).toLocaleString('vi-VN')+'đ'}
 function render(){
  if(!$('license-card'))return;
  const active=!!session?.access_token;
  document.body.classList.toggle('autotax-account-signed-out',!active);
  const displayName=String(session?.user?.user_metadata?.full_name||session?.user?.user_metadata?.display_name||'').trim();
  $('lic-header-email').hidden=!active;$('lic-header-email').textContent=active?'Xin chào bạn '+(displayName||'')+'!!!':'';
  $('lic-logout').hidden=!active;$('lic-manage-account').hidden=!active;$('lic-renew-now').hidden=!active;
  $('lic-auth').hidden=active;$('lic-account').hidden=!active;
  $('lic-account-quick-actions').hidden=!active;
  const rows=license?.packages||{},inv=rows.invoice||{},mst=rows.mst||{};
  const invLeft=Number(inv.remaining||0),invBought=Number(inv.purchased||0),mstCount=Number(mst.active_quantity||0);
  const teamLeft=Number(license?.team_invoice_remaining||0),teamSpendable=Number(license?.team_invoice_spendable_remaining||0);
  const teamMstCount=Number(license?.team_mst_count||0),teamMstCapacity=Number(license?.team_mst_package_capacity||0);
  const teamBought=Number(license?.team_invoice_purchased||0);
  const invoiceMstGrants=Number(license?.team_invoice_shared_mst_count||0);
  // A paid T-package remains owned even when all new invoice quota is spent.
  const hasInvoice=invBought>0||teamLeft>0||!!license?.team_invoice_available||!!license?.can_reread_charged_invoices;
  const canInvoice=invLeft>0||teamSpendable>0;
  const hasMst=mstCount>0||teamMstCount>0;
  const choice=globalThis.AutoTaxAccountFlow.quotaModes(license);
  const mode=choice.selected;
  $('lic-mode-wrap').hidden=!active;
  for(const option of $('lic-mode').options){
   const visible=choice.options.includes(option.value);
   option.hidden=!visible;option.disabled=!visible;
  }
  $('lic-mode').value=mode;
  $('lic-mode').disabled=choice.options.length<2;
  $('lic-mode').title='Gói MST riêng và quyền số tờ của trưởng nhóm đều được tính. Chỉ chạy một chế độ mỗi lần.';
  const quotaUser=session?.user?.id||'';
  const isQuotaExhausted=active&&mode==='invoice'&&invBought>0&&invLeft<=0&&teamLeft<=0;
  if(isQuotaExhausted&&invoiceQuotaPopupUser!==quotaUser){
   invoiceQuotaPopupUser=quotaUser;
   showInvoiceQuotaPopup();
  }
  if(!isQuotaExhausted)invoiceQuotaPopupUser='';
  const allowLink=$('demoMstAllowlistLink');
  if(allowLink)allowLink.hidden=!active||mstCount<1;
  const hddtToggle=$('lic-hddt-toggle');
  if(hddtToggle){
   const gdtPanel=$('demoGdtDetails');
   hddtToggle.hidden=!active;
   hddtToggle.setAttribute('aria-expanded',String(active&&!!gdtPanel&&!gdtPanel.hidden));
  }
  const holder=$('lic-entitlements');holder.replaceChildren();
  const card=document.createElement('div');card.className='license-entitlement';
  const info=document.createElement('div'),heading=document.createElement('b'),detail=document.createElement('small'),value=document.createElement('strong');
  if(mode==='invoice'){
   heading.textContent='Số tờ hóa đơn còn lại / đã mua';
   detail.textContent='Cá nhân: '+invLeft.toLocaleString('vi-VN')+' · Nhóm: '+teamLeft.toLocaleString('vi-VN')+
      (teamLeft>0&&invoiceMstGrants===0?' (chưa được cấp MST)':' · ưu tiên trừ nhóm trên MST được chia sẻ');
   value.textContent=(invLeft+teamLeft).toLocaleString('vi-VN')+' / '+(invBought+teamBought).toLocaleString('vi-VN');
  }else{
   heading.textContent='Số MST được quản lý';
   detail.textContent='Hạn gói cá nhân: '+(mst.farthest_expiry?new Date(mst.farthest_expiry).toLocaleDateString('vi-VN'):'—')+(teamMstCapacity?' · nhóm cấp '+teamMstCapacity+' MST, đã chia sẻ '+teamMstCount+' MST':'');
   info.append(heading,detail);
   const whitelistHint=document.createElement('small');
   whitelistHint.textContent='MST được cấp quyền: '+profileAllowedMsts.length+'/'+(mstCount+teamMstCapacity)+
    ' · Thiết lập trong Quản lý tài khoản';
   info.append(whitelistHint);
   if(mst.nearest_expiry){
    const exp=document.createElement('small');
    exp.textContent=Number(mst.expiring_quantity||0)+' MST hết hạn ngày '+new Date(mst.nearest_expiry).toLocaleDateString('vi-VN');
    info.append(exp);
   }
   value.textContent=(mstCount+teamMstCapacity).toLocaleString('vi-VN')+' MST';
  }
  if(mode==='invoice')info.append(heading,detail);
  if(mode==='mst')card.classList.add('mst-entitlement-card');
  card.append(info,value);
  // Profile selection is managed exclusively on the customer portal.
  holder.append(card);
  $('lic-state').textContent=mode==='invoice'&&(invLeft+teamSpendable)===0&&license?.can_reread_charged_invoices?'Hết lượt mới · được đọc lại hóa đơn cũ':license?.allowed?'Đã kích hoạt':(teamLeft>0||teamMstCapacity>0)?'Đã cấp gói nhóm · chờ chia sẻ MST':'Chưa có quyền sử dụng';
  $('lic-state').className='lic-state '+(license?.allowed?'active':'locked');
  const trialPanel=$('lic-trial-panel');if(trialPanel)trialPanel.hidden=!active||!!license?.allowed||!!license?.ever_had_package||!!license?.trial_used||trialActivationConfirmed;
  gate();
 }
 async function status(){
  if(!session?.access_token){license={allowed:false,reason:'Đăng nhập để xem gói sử dụng.'};emit();return license}
  const requestedUserId=session.user?.id;
  // Fetch identity and entitlement concurrently, saving one network round trip
  // without bypassing the server's mandatory-reset/authorization checks.
  const [authResult,quotaResult]=await Promise.allSettled([
   authed('/auth/v1/user',{method:'GET'}),
   rpc('autotax_my_entitlements_v118')
  ]);
  // A late response must not restore data from a user who just signed out
  // or switched to another account.
  if(!requestedUserId||session?.user?.id!==requestedUserId)return license;
  if(authResult.status==='fulfilled'){
   const latest=authResult.value;
   if(latest?.id&&latest.id===session?.user?.id){session.user=latest;void save()}
  }else console.warn('Chưa cập nhật được trạng thái tài khoản:',authResult.reason?.message);
  if(session?.user?.app_metadata?.autotax_force_password_change){
   await globalThis.DemoSecureStorage?.removeItem(LOGIN_PREF_KEY).catch(()=>{});
   license={allowed:false,force_password_change:true,reason:'Mật khẩu tạm: cần thay đổi ngay'};
   $('lic-password-box').hidden=true;
   const popup=$('lic-forced-password-dialog');
   if(popup&&!popup.open){
    $('lic-forced-password-new').value='';
    $('lic-forced-password-confirm').value='';
    $('lic-forced-password-error').hidden=true;
    popup.showModal();
   }
   message('Mật khẩu đã được Admin đặt lại. Hãy nhập hai lần mật khẩu mới trong popup.',true);
   emit();return license;
  }
  if($('lic-forced-password-dialog')?.open)$('lic-forced-password-dialog').close();
  if(quotaResult.status==='rejected')throw quotaResult.reason;
  license=quotaResult.value;
  // Server-side permissions remain authoritative; cached login never grants access.
  emit();return license;
 }
 let lastAccountCatalogueAt=0;
 async function check(){
  if(checking)return license;
  checking=true;
  try{await status()}
  catch(e){
   license={allowed:false,offline:true,reason:e.message};emit();
   message('Đang chờ đồng bộ quyền sử dụng: '+e.message,true);
  }finally{checking=false}
  render();
  if(session?.access_token&&Date.now()-lastAccountCatalogueAt>45000){
   lastAccountCatalogueAt=Date.now();
   // Download MST list and prices without blocking the signed-in screen.
   void Promise.allSettled([loadMyMst(),loadPackages()]).catch(e=>
    console.warn('Đồng bộ danh mục tài khoản chưa hoàn tất:',e.message));
  }
  return license;
 }
 // Console only needs a fresh quota snapshot. Do not download profiles,
 // re-check packages or reset the session while the invoice scan is active.
 async function refreshQuota(){
  if(checking||!session?.access_token)return license;
  checking=true;
  try{
   // Lightweight polling: avoid full auth/profile reload while scanning.
   const current=await authed('/rest/v1/rpc/autotax_my_entitlements_v118',{
    method:'POST',body:'{}',signal:AbortSignal.timeout(12000)
   });
   if(current)license=current;
  }catch(error){console.warn('Chưa làm mới được hạn mức phiên quét:',error.message)}
  finally{checking=false}
  return license;
 }
 const accountFlow=globalThis.AutoTaxAccountFlow;
 const DUPLICATE_EMAIL_MESSAGE='Email đã tồn tại.';
 function signupEmailExists(error){
  return /user_already_exists|email_exists|identity_already_exists|user already registered|email already (registered|exists|in use)|already registered/i.test(String(error?.message||error||''));
 }
 function registerStatus(value,failed=false){
  const el=$('lic-register-status');el.hidden=!value;el.textContent=value||'';
  el.classList.toggle('error',failed);
 }
 async function auth(kind){
  const registering=kind==='register';
  const email=accountFlow.normalizeEmail($(registering?'lic-register-email':'lic-email').value),password=$(registering?'lic-register-password':'lic-password').value;
  if(!email||!password){
   if(registering)return registerStatus('Vui lòng nhập email và mật khẩu AutoTax.',true);
   return message('Nhập email và mật khẩu.',true);
  }
  if(kind==='register'&&!accountFlow.validEmail(email))
   return registerStatus('Chỉ hỗ trợ đăng ký bằng Gmail, Hotmail hoặc Yahoo Mail.',true);
  $('lic-login').disabled=$('lic-register').disabled=true;
  if(registering){$('lic-register-submit').disabled=true;registerStatus('Đang đăng ký tài khoản trên máy chủ…')}
  try{
   if(kind==='register'){
    const name=accountFlow.normalizeName($('lic-register-name').value);
    const username=$('lic-register-username').value.trim().toLowerCase();
    const invalid=accountFlow.validateSignup({name,email,password,confirmPassword:$('lic-register-confirm').value});
    if(!accountFlow.validUsername(username))return registerStatus('User đăng nhập phải có 4–32 ký tự hợp lệ.',true);
    if(invalid)return registerStatus(invalid,true);
    const available=await request('/rest/v1/rpc/autotax_username_available_v130',
       {method:'POST',body:JSON.stringify({p_username:username}),signal:AbortSignal.timeout(15000)},null);
    if(!available)return registerStatus('User đăng nhập đã được sử dụng.',true);
    const signup=await request('/auth/v1/signup',
       {method:'POST',body:JSON.stringify({email,password,data:{full_name:name,display_name:name,username}}),signal:AbortSignal.timeout(25000)},null);
    // Supabase may return an obfuscated user with no identities instead of an error.
    if(accountFlow.duplicateSignup(signup))
     return registerStatus(DUPLICATE_EMAIL_MESSAGE,true);
    // Never start an authenticated session implicitly: return to the login form.
    if(signup?.access_token){
     await request('/auth/v1/logout',{method:'POST'},signup.access_token).catch(error=>
       console.warn('Không thu hồi được phiên mới tạo:',error.message));
    }
    $('lic-signup-dialog').close();
    $('lic-email').value=email;$('lic-password').value=password;
    message(signup?.access_token?
      'Đã tạo tài khoản thành công. Email và mật khẩu đã điền sẵn, bấm Đăng nhập để tiếp tục.':
      'Đã tạo yêu cầu đăng ký và điền sẵn email, mật khẩu. Supabase vẫn yêu cầu xác minh email; cần tắt Confirm Email trên máy chủ để đăng nhập ngay.');
    $('lic-login').focus();
    return;
   }else{
    session=email.includes('@')?await request('/auth/v1/token?grant_type=password',
     {method:'POST',body:JSON.stringify({email,password})},null):await accountFlow.usernameSession(email,password);
   }
   // A valid Auth response is sufficient to show the signed-in panel.
   // Persist the token before background vault/catalog sync; never block the UI
   // on network calls for quota, packages, MST profiles or vault decryption.
   await save();
   const signedInUserId=session?.user?.id||'';
   license={allowed:false,reason:'Đang đồng bộ quyền sử dụng…'};
   $('lic-password').value='';
   render();emit();
   message('Đăng nhập thành công. Đang đồng bộ quyền sử dụng…');
   void (async()=>{
    try{
     if(session?.user?.id!==signedInUserId)return;
     await check();
    }catch(error){console.warn('Không đồng bộ được gói sau đăng nhập:',error.message)}
   })();
   void (async()=>{
    if(session?.user?.id!==signedInUserId)return;
    if(session?.user?.app_metadata?.autotax_force_password_change){
     await globalThis.DemoSecureStorage?.removeItem(LOGIN_PREF_KEY).catch(()=>{});
     return;
    }
    await rememberLogin(email,password).catch(e=>console.warn('Không lưu được tài khoản:',e.message));
    try{
     await window.AutoTaxSharedMstVault?.unlock(signedInUserId,password);
     if(session?.user?.id===signedInUserId)
      document.dispatchEvent(new CustomEvent('autotax-vault-unlocked',{detail:{userId:signedInUserId}}));
    }catch(error){console.warn('Kho MST chưa mở khóa:',error.message)}
   })();
  }catch(e){
   const timedOut=e.name==='TimeoutError'||e.name==='AbortError';
   if(registering)registerStatus(timedOut?'Máy chủ phản hồi quá chậm. Kiểm tra mạng rồi thử lại.':signupEmailExists(e)?DUPLICATE_EMAIL_MESSAGE:accountFlow.message(e),true);
   else message(accountFlow.message(e),true);
  }finally{
   $('lic-login').disabled=$('lic-register').disabled=false;
   if(registering)$('lic-register-submit').disabled=false;
  }
 }
 async function loadPackages(){
  try{
   packages=await rpc('addon_list_packages');
   const fingerprint=JSON.stringify(packages||[]);
   if(fingerprint===renderedPackagesFingerprint&&$('lic-package-list')?.childElementCount)return;
   renderedPackagesFingerprint=fingerprint;
   const data365=packages?.find(p=>p.code==='DATA365');
   const buyData=$('tendooData365Buy');
   if(buyData){
    buyData.disabled=!data365;
    buyData.textContent=data365?'Mua DATA365 · '+money(data365.price_vnd):
      'DATA365 chưa mở bán';
   }
   const holder=$('lic-package-list');holder.replaceChildren();
   const defaults=['T100','T200','T500','T1000','T5000','MST1','MST5','MST10','MST20','MST50'];
   const ordered=[...defaults.map(code=>(packages||[]).find(p=>p.code===code)).filter(Boolean),
     ...(packages||[]).filter(p=>!defaults.includes(p.code)).sort((a,b)=>(a.code==='DATA365'?-1:b.code==='DATA365'?1:0))];
   let customHeading=false;
   for(const p of ordered){
    if(!defaults.includes(p.code)&&!customHeading){
     const heading=document.createElement('strong');heading.textContent='Gói bổ sung';
     heading.style.cssText='display:block;width:100%;padding:8px 0;color:#b80010';
     holder.append(heading);customHeading=true;
    }
    const card=document.createElement('div');card.className='license-package';
    const details=document.createElement('div');
    const name=document.createElement('b');name.textContent=p.name||p.code;
    const description=document.createElement('small');
    description.textContent=p.family==='storage'
      ? (p.description||'Đồng bộ file danh mục hàng hóa giữa các thiết bị')+' · '+(p.validity_days||365)+' ngày. Không ảnh hưởng số lượt/MST.'
      : p.family==='mst'
      ? (p.description?p.description+' · ':'')+(p.validity_days?p.validity_days+' ngày · ':'')+'Không giới hạn số hóa đơn tra cứu trong phạm vi MST được quản lý.'
      : (p.description?p.description+' · ':'')+'Không giới hạn MST tra cứu theo số lượt đã mua; tối đa 100 hồ sơ MST lưu cùng lúc.';
    const price=document.createElement('strong');price.textContent=money(p.price_vnd);
    details.append(name,description,price);
    const button=document.createElement('button');button.type='button';button.textContent='Chọn mua';
    button.dataset.package=p.code;
    button.disabled=p.family==='mst'&&!p.validity_days;
    card.append(details,button);holder.append(card);
   }
   if(!holder.childElementCount){const empty=document.createElement('small');empty.textContent='Hiện chưa có gói mở bán.';holder.append(empty)}
  }catch(e){message('Không tải được danh sách gói: '+e.message,true)}
 }
 async function chooseMstPurchaseMode(p){
  const dialog=$('lic-mst-purchase-mode-dialog'),qty=$('lic-mst-purchase-quantity'),
   duration=$('lic-mst-purchase-duration'),cancel=$('lic-mst-purchase-cancel');
  const current=Number(license?.packages?.mst?.active_quantity||0);
  const units=Number(p.quantity||0),days=Number(p.validity_days||365);
  const combo=!!p.is_combo;
  const renewing=Math.min(current,units),additional=Math.max(0,units-renewing);
  $('lic-mst-purchase-preview').textContent=combo?
   'Gói Combo giữ quy tắc tăng số lượng như trước; không chuyển số lượt hóa đơn thành ngày MST.':
   current>0?
    (renewing+' MST đang dùng được gia hạn thêm '+days+
      ' ngày từ hạn cũ; '+additional+' MST mới (nếu có) dùng '+days+' ngày từ khi thanh toán.'):
    'Chưa có MST còn hạn để gia hạn. Chọn Tăng số lượng dùng.';
  duration.disabled=combo||current<1;
  duration.title=combo?'Gói Combo không hỗ trợ tăng thời gian':
    current<1?'Chưa có MST còn hạn để gia hạn':'Ưu tiên gia hạn số MST đang dùng';
  return new Promise(resolve=>{
   let settled=false;
   const close=mode=>{
    if(settled)return;settled=true;dialog.close();
    qty.removeEventListener('click',onQty);
    duration.removeEventListener('click',onDuration);
    cancel.removeEventListener('click',onCancel);
    dialog.removeEventListener('cancel',onCancel);
    dialog.removeEventListener('close',onCancel);
    resolve(mode);
   };
   const onQty=()=>close('capacity'),onDuration=()=>close('duration'),onCancel=()=>close(null);
   qty.addEventListener('click',onQty);
   duration.addEventListener('click',onDuration);
   cancel.addEventListener('click',onCancel);
   dialog.addEventListener('cancel',onCancel);
   dialog.addEventListener('close',onCancel);
   dialog.showModal();
  });
 }
 let paidSuccessTimeout=null,paidSuccessInterval=null;
 function closePaidSuccess(){
  if(paidSuccessTimeout)clearTimeout(paidSuccessTimeout);
  if(paidSuccessInterval)clearInterval(paidSuccessInterval);
  paidSuccessTimeout=null;paidSuccessInterval=null;
  const dialog=$('lic-payment-success-dialog');if(dialog?.open)dialog.close();
 }
 function showPaidSuccess(code,mode){
  const dialog=$('lic-payment-success-dialog');
  if(!dialog)return;
  closePaidSuccess();
  $('lic-payment-success-text').textContent='Đã ghi nhận thanh toán gói '+code+
   (mode==='duration'?' · Tăng thời gian dùng':mode==='capacity'?' · Tăng số lượng dùng':'')+
   '. Hạn mức được cập nhật từ máy chủ.';
  dialog.showModal();
  const until=Date.now()+5000;
  const tick=()=>{$('lic-payment-success-countdown').textContent=
   'Tự đóng sau '+Math.max(0,Math.ceil((until-Date.now())/1000))+' giây';};
  tick();
  paidSuccessInterval=setInterval(tick,500);
  paidSuccessTimeout=setTimeout(closePaidSuccess,5000);
 }
 $('lic-payment-success-close')?.addEventListener('click',closePaidSuccess);
 let paymentEpoch=0,activeQr=null,paymentCreating=false;
 function closePayment(inline=false){
  ++paymentEpoch;clearInterval(timer);timer=null;
  const box=$(inline?'tendooData365Payment':'lic-payment');
  if(box)box.hidden=true;
  if(!inline)activeQr=null;
 }
 async function buy(code,btn,inline=false,options={}){
  if(!session?.access_token){message('Đăng nhập AutoTax trước khi mua gói.',true);return}
  if(inline&&code!=='DATA365')throw Error('Chỉ cho phép mua DATA365 tại cấu hình nhập kho.');
  if(!btn||btn.disabled||paymentCreating)return;
  const selectedPackage=(packages||[]).find(p=>p.code===code);
  if(!inline&&selectedPackage?.family==='mst'&&!options.purchaseMode){
   const chosen=await chooseMstPurchaseMode(selectedPackage);
   if(!chosen)return;
   options={...options,purchaseMode:chosen};
  }
  paymentCreating=true;btn.disabled=true;
  const status=inline?$('tendooData365Status'):null;
  const notify=text=>{if(status)status.textContent=text;else message(text)};
  // Open the payment panel immediately and guard old responses when a user
  // closes or switches packages during the server request.
  closePayment(false);closePayment(true);
  const epoch=paymentEpoch;
  const box=$(inline?'tendooData365Payment':'lic-payment');
  const img=$(inline?'tendooData365Qr':'lic-qr');
  const info=$(inline?'tendooData365Info':'lic-payment-info');
  box.hidden=false;img.hidden=true;img.removeAttribute('src');
  info.textContent='Đang tạo đơn thanh toán '+code+' và mã QR bảo mật…';
  notify('Đang yêu cầu QR từ máy chủ…');
  try{
   const d=await authed('/functions/v1/addon-create-order',{
    method:'POST',body:JSON.stringify({package_code:code,coupon_code:options.coupon||null,replace_order_id:options.replaceId||null})
   });
   if(epoch!==paymentEpoch)return;
   if(!d.success||!d.payment?.qr_url||!d.order?.order_id)
    throw Error(d.error||'Không tạo được đơn thanh toán.');
   if(!inline&&selectedPackage?.family==='mst'){
    const mode=options.purchaseMode||'capacity';
    await rpc('autotax_set_mst_purchase_mode_v120',{
      p_order_id:d.order.order_id,p_mode:mode
    });
    if(epoch!==paymentEpoch)return;
   }
   const qrUrl=d.payment.qr_url;
   info.textContent=money(d.payment.amount_vnd)+' · '+d.payment.bank_name+
    ' · '+d.payment.account_name+' · Nội dung: '+d.payment.transfer_content;
   img.onload=()=>{if(epoch===paymentEpoch)img.hidden=false;};
   img.onerror=()=>{if(epoch===paymentEpoch)notify('Ảnh QR tải lỗi. Vui lòng thử tạo QR mới hoặc sử dụng thông tin chuyển khoản đã hiển thị.')};
   img.loading='eager';img.decoding='async';img.fetchPriority='high';
   img.src=qrUrl;
   if(!inline){
    activeQr={orderId:d.order.order_id,code,purchaseMode:options.purchaseMode||null};
    $('lic-coupon-code').value=options.coupon||'';
    $('lic-coupon-status').textContent=options.coupon?
     ('Mã '+options.coupon+' · giảm '+money(d.order.discount_amount_vnd||0)+
      ' · số tiền cần trả '+money(d.payment.amount_vnd)):
      (options.replaceId?'Đã bỏ mã và tạo QR theo giá gốc.':'Nhập mã giảm giá để nhận QR mới.');
   }
   const expires=Date.parse(d.payment.expires_at||d.order.qr_expires_at||'');
   notify('Gói '+code+(options.purchaseMode==='duration'?' · Tăng thời gian dùng':
    options.purchaseMode==='capacity'?' · Tăng số lượng dùng':'')+
    '. Thanh toán QR trong 5 phút, hệ thống tự xác nhận.');
   timer=setInterval(async()=>{
    if(epoch!==paymentEpoch)return;
    try{
     const order=await rpc('addon_my_order_status',{p_order_id:d.order.order_id});
     if(epoch!==paymentEpoch)return;
     if(order?.status==='paid'){
      closePayment(inline);await check();
      notify('Thanh toán thành công, gói '+code+' đã được kích hoạt.');
      if(!inline)showPaidSuccess(code,options.purchaseMode);
      if(inline)document.dispatchEvent(new CustomEvent('autotax-data365-active'));
      return;
     }
     if(['cancelled','failed','refunded'].includes(order?.status)){
      closePayment(inline);notify('Đơn không còn hiệu lực: '+order.status);return;
     }
     if(Number.isFinite(expires)&&Date.now()>expires){
      closePayment(inline);notify('QR đã hết hạn 5 phút. Bấm Mua DATA365 để tạo mã mới.');
     }
    }catch(error){if(epoch===paymentEpoch)notify('Đang chờ thanh toán: '+error.message)}
   },5000);
  }catch(error){
   if(epoch===paymentEpoch){
    info.textContent='Chưa tạo được QR thanh toán. '+(error.message||error);
    notify('Không tạo được đơn: '+error.message);
    if(!inline)message(error.message,true);
   }
  }finally{paymentCreating=false;btn.disabled=false}
 }
 async function redeemUnlock(){
  const input=$('lic-unlock-code'),btn=$('lic-unlock-redeem'),code=input.value.trim().toUpperCase();
  if(!code){message('Nhập mã quà tặng.',true);input.focus();return}
  btn.disabled=true;
  try{
   const result=await rpc('addon_redeem_package_unlock',{p_code:code});
   input.value='';
   const dialog=$('lic-unlock-dialog');
   if(dialog.open)dialog.close();
   await check();
   message('Đã kích hoạt gói '+result.package_code+' · '+result.quantity+
     (result.family==='mst'?' MST':' lượt hóa đơn')+
     (result.expires_at?' · hết hạn '+new Date(result.expires_at).toLocaleDateString('vi-VN'):''));
  }catch(e){message('Mã quà tặng không hợp lệ: '+e.message,true)}
  finally{btn.disabled=false}
 }
 async function startMstTrial(){
  const btn=$('lic-trial-start');btn.disabled=true;
  try{
   const result=await rpc('addon_start_dual_trial');
   trialActivationConfirmed=true;$('lic-trial-panel').hidden=true;
   await check();
   message('Đã kích hoạt dùng thử 7 ngày: quản lý 1 MST và 100 tờ hóa đơn. Tự do tra cứu trong chế độ số tờ; đăng ký MST sau khi chuyển chế độ MST. Hết hạn '+new Date(result.expires_at).toLocaleDateString('vi-VN')+'.');
  }catch(e){message('Không kích hoạt được dùng thử: '+e.message,true)}
  finally{btn.disabled=false}
 }
 async function mstConsentStatus(mst){
  return rpc('autotax_mst_consent_status_v128',{p_mst:String(mst||'').replace(/\D/g,'')});
 }
 async function mstConsentDecide(mst,grant){
  return rpc('autotax_mst_consent_decide_v128',
    {p_mst:String(mst||'').replace(/\D/g,''),p_grant:!!grant});
 }
 async function rememberSignedInMst(mst,{grant=true}={}){
  if(!session?.access_token)throw Error('Vui lòng đăng nhập AutoTax.');
  const number=String(mst||'').replace(/\D/g,'');
  if(!/^(?:\d{10}|\d{12}|\d{13})$/.test(number))throw Error('MST không hợp lệ.');
  // Every verified GDT login is saved, including counted-invoice mode.
  // Only MST mode can auto-grant an unused paid/trial whitelist slot.
  // A shared team MST is read-only; signing in must not spend a personal MST slot.
  if((license?.team_mst_allowed_msts||[]).includes(number)||sharedInvoiceMsts.includes(number)){
   await loadMyMst();return {allowed:true,source:'team'};
  }
  if(!grant){
   // Explicitly saving a profile must not silently spend a paid MST whitelist slot.
   if(profileAllowedMsts.includes(number))return {allowed:true,source:'previous_grant'};
   await rpc('addon_add_mst_profile_v33',{p_mst:number});
   await loadMyMst();
   return {allowed:false,warning:'grant_not_selected'};
  }
  const result=await rpc('addon_register_gdt_signin_v115',{p_mst:number});
  await loadMyMst();
  return result;
 }
 function requireMstAllowed(mst){
  const number=String(mst||'').replace(/\D/g,'');
  if(license?.mode==='invoice'){
   if(Number(license?.packages?.invoice?.remaining||0)>0 ||
      license?.can_reread_charged_invoices || sharedInvoiceMsts.includes(number))return true;
  }else if(profileAllowedMsts.includes(number))return true;
  const dlg=$('lic-mst-limit-dialog');if(dlg&&!dlg.open)dlg.showModal();
  return false;
 }
 async function markTaxPasswordUpdated(mst){
  try{await rpc('addon_mark_mst_password_updated',{p_mst:mst})}
  catch(error){console.warn('Không ghi được ngày cập nhật mật khẩu Thuế:',error.message)}
 }
 function ensureTrialPanel(){
  if($('lic-trial-start')){if(!$('lic-trial-start').dataset.bound){$('lic-trial-start').addEventListener('click',startMstTrial);$('lic-trial-start').dataset.bound='1'}return;}if(!$('lic-entitlements'))return;
  const wrapper=document.createElement('div');wrapper.id='lic-trial-panel';wrapper.className='license-entitlement';
  const content=document.createElement('div');
  const title=document.createElement('b');title.textContent='Dùng thử 7 ngày · 1 MST + 100 tờ';
  const hint=document.createElement('small');hint.textContent='Không cần MST để kích hoạt. Sau đó thêm MST trong Quản lý tài khoản hoặc ngay màn hình đăng nhập cổng Thuế.';
  const input=document.createElement('input');input.id='lic-trial-mst';input.hidden=true;
  const button=document.createElement('button');button.id='lic-trial-start';button.type='button';button.textContent='Kích hoạt dùng thử';
  button.addEventListener('click',startMstTrial);
  content.append(title,hint,input);wrapper.append(content,button);
  $('lic-entitlements').insertAdjacentElement('afterend',wrapper);
 }
 const verifiedName=value=>{
  const s=String(value||'').trim().replace(/\s+/g,' ');
  return s.length>=3&&s.length<=120&&/[\p{L}]/u.test(s)&&
   !/^(khách lẻ|khach le)$/i.test(s)?s:'';
 };
 async function autoNameFromGdt(info){
  const mst=String(info?.mst||'').replace(/\D/g,''),
   label=verifiedName(info?.company);
  if(!session?.access_token||!label||!profileMsts.includes(mst))return false;
  try{
   const rows=await rpc('addon_list_my_mst_assignments');
   const item=(rows||[]).find(x=>String(x.mst||'').replace(/\D/g,'')===mst);
   if(!item||item.name_verified_at)return false;
   await rpc('addon_confirm_gdt_mst_name',{p_mst:mst,p_display_name:label});
   await loadMyMst();return true;
  }catch(e){console.warn('AutoTax: không lưu được tên hồ sơ đã xác thực',e.message);return false}
 }
 async function loadMyMst(){
  if(!session?.access_token){
   profileMsts=[];profileAllowedMsts=[];profileNames={};sharedInvoiceMsts=[];sharedProfileMsts=[];emitProfiles();return;
  }
  const requestedUserId=session.user?.id;
  try{
   const [rows,sharedProfiles]=await Promise.all([
      rpc('addon_list_my_mst_assignments'),
      rpc('autotax_team_shared_mst_profiles_v119')
   ]);
   if(!requestedUserId||session?.user?.id!==requestedUserId)return;
   const shared=Array.isArray(sharedProfiles)?sharedProfiles:[];
   sharedProfileMsts=shared.map(x=>String(x.mst||'').replace(/\D/g,'')).filter(Boolean);
   sharedInvoiceMsts=shared.filter(x=>x.can_use_invoice_package===true)
     .map(x=>String(x.mst||'').replace(/\D/g,'')).filter(Boolean);
   const current=globalThis.AutoTaxGdtProfile;
   const approved=verifiedName(current?.company),
    verifiedMst=String(current?.mst||'').replace(/\D/g,'');
   if(approved){
    const match=(rows||[]).find(x=>String(x.mst||'').replace(/\D/g,'')===verifiedMst);
    if(match&&!match.name_verified_at){
     try{
      await rpc('addon_confirm_gdt_mst_name',{p_mst:verifiedMst,p_display_name:approved});
      match.display_name=approved;match.name_verified_at=new Date().toISOString();
     }catch(error){console.warn('Chưa đồng bộ được tên NNT:',error.message)}
    }
   }
   const teamMsts=(license?.team_mst_allowed_msts||[]).map(x=>String(x||'').replace(/\D/g,'')).filter(Boolean);
   const nextProfiles=[...new Set([...(rows||[]).map(x=>String(x.mst||'').replace(/\D/g,'')).filter(Boolean),
     ...shared.map(x=>String(x.mst||'').replace(/\D/g,'')).filter(Boolean),...teamMsts])];
   const removed=profileMsts.filter(m=>!nextProfiles.includes(m));
   if(removed.length&&session.user?.id){
    const historyKey='autotax_invoice_history_v1';
    const stored=await chrome.storage.local.get(historyKey);
    const history=stored[historyKey];
    if(history?.records){
     for(const [key,value] of Object.entries(history.records))
      if(removed.includes(String(value.mst||key.split('|')[0])))
       delete history.records[key];
     await chrome.storage.local.set({[historyKey]:history});
    }
    for(const mst of removed)
     await globalThis.DemoSecureStorage?.removeItem('gdt:'+session.user.id+':'+mst).catch(()=>{});
   }
   profileMsts=nextProfiles;
   void migratePreviousMstPasswords(nextProfiles);
   profileAllowedMsts=[...new Set([...(rows||[]).filter(x=>x.mst_allowed===true)
     .map(x=>String(x.mst||'').replace(/\D/g,'')).filter(Boolean),...teamMsts,...sharedInvoiceMsts])];
   profileNames=Object.fromEntries((rows||[])
    .map(x=>[String(x.mst||'').replace(/\D/g,''),verifiedName(x.display_name)])
    .filter(([,value])=>!!value));
   for(const profile of shared){
    const mst=String(profile.mst||'').replace(/\D/g,'');
    if(mst&&!profileNames[mst])profileNames[mst]=String(profile.display_name||'MST nhóm · chỉ xem');
   }
   for(const mst of teamMsts)if(!profileNames[mst])profileNames[mst]='MST nhóm · chỉ xem';
   emitProfiles();
   render();
   void showPasswordAgeReminder(rows||[]).catch(()=>{});
  }catch(error){
   profileMsts=[];profileAllowedMsts=[];profileNames={};sharedInvoiceMsts=[];sharedProfileMsts=[];emitProfiles();
   message('Không tải được danh sách hồ sơ MST: '+error.message,true);
  }
 }
 async function showPasswordAgeReminder(rows){
  if(license?.mode!=='mst'||!session?.user?.id)return;
  const due=(rows||[]).find(row=>row.password_updated_at&&
   Date.now()-new Date(row.password_updated_at).getTime()>=80*86400000);
  if(!due)return;
  const key='autotax-gdt-pwd-reminder-v113-'+session.user.id+':'+due.mst;
  const today=new Date().toISOString().slice(0,10);
  const saved=await chrome.storage.local.get(key);
  if(saved[key]===today)return;
  await chrome.storage.local.set({[key]:today});
  const popup=$('lic-password-age-dialog');
  if(popup&&!popup.open){
   const days=Math.floor((Date.now()-new Date(due.password_updated_at).getTime())/86400000);
   $('lic-password-age-text').textContent='MST '+due.mst+' đã '+days+
    ' ngày kể từ khi lưu/sửa mật khẩu trong AutoTax. Hãy kiểm tra mật khẩu trên cổng Thuế.';
   popup.showModal();
  }
 }
 async function completeForcedPassword(){
  const dialog=$('lic-forced-password-dialog'),
   password=$('lic-forced-password-new').value,
   confirmed=$('lic-forced-password-confirm').value,
   errorBox=$('lic-forced-password-error'),
   button=$('lic-forced-password-save');
  const fail=text=>{errorBox.textContent=text;errorBox.hidden=false};
  errorBox.hidden=true;
  if(password.length<8||password.length>128)return fail('Mật khẩu phải dài từ 8 đến 128 ký tự.');
  if(password==='000000')return fail('Không được dùng lại mật khẩu tạm 000000.');
  if(password!==confirmed)return fail('Hai lần nhập mật khẩu chưa trùng khớp.');
  if(!session?.access_token)return fail('Phiên đăng nhập đã hết hạn.');
  button.disabled=true;
  try{
   const result=await authed('/functions/v1/autotax-admin-password-reset',{
    method:'POST',body:JSON.stringify({action:'complete',new_password:password})
   });
   if(!result?.ok)throw Error(result?.error||'Không thể lưu mật khẩu mới.');
   // Close the successful admin-reset popup before local vault cleanup.
   if(dialog?.open)dialog.close();
   try{await window.AutoTaxSharedMstVault?.rekey(password)}
   catch(e){console.warn('Khóa đồng bộ MST cần khôi phục sau khi đổi mật khẩu:',e.message)}
   const email=session.user?.email||'';
   session=null;license={allowed:false};await save();
   await globalThis.DemoSecureStorage?.removeItem(LOGIN_PREF_KEY).catch(()=>{});
   $('lic-email').value=email;$('lic-password').value='';
   $('lic-forced-password-new').value='';$('lic-forced-password-confirm').value='';
   if(dialog.open)dialog.close();
   $('lic-password-box').hidden=true;render();
   message('Đã đổi mật khẩu. Hãy đăng nhập lại bằng mật khẩu mới.');
  }catch(e){fail('Không lưu được mật khẩu: '+(e.message||String(e)))}
  finally{button.disabled=false}
 }
 async function changePassword(){
  const current=$('lic-current-password').value,password=$('lic-new-password').value,
   forced=!!session?.user?.app_metadata?.autotax_force_password_change;
  if(!forced&&!current)return message('Nhập mật khẩu hiện tại để xác minh.',true);
  if(password.length<(forced?10:8))return message('Mật khẩu mới phải có ít nhất '+(forced?10:8)+' ký tự.',true);
  if(current===password)return message('Mật khẩu mới phải khác mật khẩu hiện tại.',true);
  const btn=$('lic-password-save');btn.disabled=true;
  try{
   if(forced){
    const result=await authed('/functions/v1/autotax-admin-password-reset',{
     method:'POST',body:JSON.stringify({action:'complete',new_password:password})
    });
    if(!result.ok)throw Error(result.error||'Không đổi được mật khẩu tạm.');
    try{await window.AutoTaxSharedMstVault?.rekey(password)}
    catch(e){console.warn('Đổi mật khẩu tạm nhưng chưa re-key MST:',e.message)}
    const email=session.user.email;
    session=null;license={allowed:false};await save();
    await globalThis.DemoSecureStorage?.removeItem(LOGIN_PREF_KEY).catch(()=>{});
    $('lic-email').value=email||'';$('lic-password').value='';
    message('Đã đổi mật khẩu tạm. Hãy đăng nhập lại bằng mật khẩu mới.');
    $('lic-password-box').hidden=true;render();return;
   }
   const verified=await request('/auth/v1/token?grant_type=password',{
    method:'POST',body:JSON.stringify({email:session?.user?.email,password:current})
   },null);
   if(!verified?.access_token)throw Error('Không xác minh được mật khẩu hiện tại.');
   session=verified;await save();
   await authed('/auth/v1/user',{method:'PUT',body:JSON.stringify({password})});
   try{await window.AutoTaxSharedMstVault?.rekey(password)}
   catch(e){message('Đã đổi mật khẩu AutoTax, nhưng cần cập nhật khóa MST: '+e.message,true)}
   await rememberLogin(session?.user?.email,password).catch(()=>{});
   $('lic-current-password').value='';$('lic-new-password').value='';
   $('lic-password-box').hidden=true;message('Đã cập nhật mật khẩu.');
  }catch(e){message(e.message,true)}finally{btn.disabled=false}
 }
 async function logout(){
  const token=session?.access_token;
  session=null;license={allowed:false};profileMsts=[];profileAllowedMsts=[];
  profileNames={};sharedInvoiceMsts=[];sharedProfileMsts=[];lastAccountCatalogueAt=0;
  emitProfiles();emit();render();closePayment(false);closePayment(true);
  $('lic-email').value='';$('lic-password').value='';
  await Promise.allSettled([save(),globalThis.DemoSecureStorage?.removeItem(LOGIN_PREF_KEY)]);
  message('Đã đăng xuất. Lần mở tiếp theo cần đăng nhập lại.');
  if(token)void request('/auth/v1/logout',{method:'POST'},token)
   .catch(e=>console.warn('Chưa thu hồi được token từ máy chủ:',e.message));
 }
 async function init(){
  ensureTrialPanel();
  // Local session first: render instantly. No network or vault operation is
  // allowed to block the previously authenticated account from appearing.
  const stored=await chrome.storage.local.get(STORE);
  session=stored[STORE]||null;
  if(session?.access_token&&session?.refresh_token&&session?.user?.id){
   render();emit();
   $('lic-password').value='';
   void check();
   // Unlock the cross-device tax-password vault separately, after the panel appears.
   if(!session.user?.app_metadata?.autotax_force_password_change)
    void (async()=>{
     try{
      const raw=await globalThis.DemoSecureStorage?.getItem(LOGIN_PREF_KEY);
      const saved=raw?JSON.parse(raw):null;
      if(saved?.password&&session?.user?.id){
       const owner=session.user.id;
       await window.AutoTaxSharedMstVault?.unlock(owner,saved.password);
       if(session?.user?.id===owner){
        void migratePreviousMstPasswords(profileMsts);
        document.dispatchEvent(new CustomEvent('autotax-vault-unlocked',{detail:{userId:owner}}));
       }
      }
     }catch(e){console.warn('Kho MST chờ được mở khóa:',e.message)}
    })();
  }else{
   session=null;render();emit();
   void restoreLogin();
  }
  setInterval(()=>{if(!document.hidden&&session?.access_token&&!checking&&
    !document.querySelector('dialog[open]')&&!document.body.classList.contains('autotax-scanning'))
    void check()},180000);
 }
 chrome.storage.onChanged.addListener((changes,area)=>{
  if(area!=='local'||!changes[STORE])return;
  const next=changes[STORE].newValue||null;
  const same=(session?.access_token||'')===(next?.access_token||'')&&
    (session?.refresh_token||'')===(next?.refresh_token||'')&&
    (session?.user?.id||'')===(next?.user?.id||'');
  if(same)return;
  session=next?.access_token&&next?.refresh_token&&next?.user?.id?next:null;
  if(!session){
   license={allowed:false};profileMsts=[];profileAllowedMsts=[];profileNames={};
   sharedInvoiceMsts=[];sharedProfileMsts=[];lastAccountCatalogueAt=0;
   emitProfiles();render();emit();message('');
   return;
  }
  license={allowed:false,reason:'Đang đồng bộ quyền sử dụng…'};
  render();emit();message('');
  void check().catch(error=>console.warn('Chưa đồng bộ được phiên Web vào Add-on:',error.message||error));
 });
 document.addEventListener('DOMContentLoaded',()=>{
  for(const id of ['lic-name','lic-email','lic-password'])$(id).addEventListener('keydown',event=>{
   if(event.key==='Enter'){
    event.preventDefault();
    void auth($('lic-name').hidden?'login':'register');
   }
 });
 $('lic-limit-close')?.addEventListener('click',()=>$('lic-mst-limit-dialog').close());
 $('lic-invoice-limit-close')?.addEventListener('click',()=>$('lic-invoice-limit-dialog').close());
 document.addEventListener('autotax-invoice-quota-exhausted',showInvoiceQuotaPopup);
 $('lic-password-age-close')?.addEventListener('click',()=>$('lic-password-age-dialog').close());
 // A focus/visibility event often comes from Chrome's own side-panel window.
 // Never rebuild the whole account panel merely because the user switched tabs.
 // The single background refresh is scheduled by init(), not here.
 $('lic-login').addEventListener('click',()=>void auth('login'));
 const signupDialog=$('lic-signup-dialog');
 const closeSignup=()=>{if(signupDialog.open)signupDialog.close()};
 $('lic-register').addEventListener('click',()=>{
   registerStatus('');
   $('lic-register-email').value=$('lic-email').value.includes('@')?$('lic-email').value:'';
   if(!signupDialog.open)signupDialog.showModal();
   $('lic-register-name').focus();
 });
 $('lic-register-close').addEventListener('click',closeSignup);
 signupDialog.addEventListener('cancel',event=>event.preventDefault());
 signupDialog.addEventListener('click',event=>{if(event.target===signupDialog)event.preventDefault()});
 $('lic-signup-form').addEventListener('submit',e=>{e.preventDefault();void auth('register')});
 $('lic-register-cancel').addEventListener('click',closeSignup);
 $('lic-forgot-password').addEventListener('click',()=>{
  $('lic-forgot-email').value=$('lic-email').value.includes('@')?$('lic-email').value:'';
  $('lic-forgot-status').hidden=true;$('lic-forgot-dialog').showModal();
 });
 const closeForgot=()=>{const popup=$('lic-forgot-dialog');if(popup?.open)popup.close()};
 const forgotPopup=$('lic-forgot-dialog');
 forgotPopup.addEventListener('cancel',event=>event.preventDefault());
 forgotPopup.addEventListener('click',event=>{if(event.target===forgotPopup)event.preventDefault()});
 $('lic-forgot-cancel').addEventListener('click',closeForgot);
 $('lic-forgot-close').addEventListener('click',closeForgot);
 $('lic-forgot-form').addEventListener('submit',async e=>{
  e.preventDefault();
  const email=accountFlow.normalizeEmail($('lic-forgot-email').value);
  const status=$('lic-forgot-status');
  if(!accountFlow.validEmail(email)){
    status.textContent='Nhập email đã đăng ký để đặt lại mật khẩu.';status.hidden=false;return;
  }
  const button=$('lic-forgot-submit');button.disabled=true;
  try{
   await request('/auth/v1/recover?redirect_to='+encodeURIComponent('https://tracuuhoadon.top/'),{
    method:'POST',body:JSON.stringify({email})
   },null);
   status.textContent=accountFlow.forgotSuccess;status.hidden=false;
  }catch(error){
   status.textContent=accountFlow.message(error);status.hidden=false;
  }finally{button.disabled=false}
 });
 $('lic-logout').addEventListener('click',logout);$('lic-packages-close').addEventListener('click',()=>$('lic-packages').hidden=true);$('lic-package-list').addEventListener('click',e=>{const b=e.target.closest('[data-package]');if(b)buy(b.dataset.package,b)});$('lic-gift-open').addEventListener('click',()=>{
  const dialog=$('lic-unlock-dialog');
  if(!dialog.open)dialog.showModal();
  $('lic-unlock-code').focus();
 });
 $('lic-unlock-close').addEventListener('click',()=>$('lic-unlock-dialog').close());
 const forcedDialog=$('lic-forced-password-dialog');
 forcedDialog.addEventListener('cancel',e=>e.preventDefault());
 forcedDialog.addEventListener('click',e=>{if(e.target===forcedDialog)e.preventDefault()});
 $('lic-forced-password-form').addEventListener('submit',e=>{e.preventDefault();void completeForcedPassword()});
 $('lic-unlock-form').addEventListener('submit',e=>{e.preventDefault();void redeemUnlock()});$('lic-password-open').addEventListener('click',()=>$('lic-password-box').hidden=!$('lic-password-box').hidden);$('lic-password-save').addEventListener('click',changePassword);$('lic-mode').addEventListener('change',async e=>{try{await rpc('autotax_set_usage_mode_v118',{p_mode:e.target.value});license.mode=e.target.value;await check();message('Đã đổi chế độ.')}catch(err){message(err.message,true);e.target.value=license?.mode||'mst'}});$('lic-coupon-apply').addEventListener('click',()=>{
 const order=activeQr;if(!order)return message('Chưa có QR thanh toán.',true);
 const coupon=$('lic-coupon-code').value.trim().toUpperCase();
 void buy(order.code,$('lic-coupon-apply'),false,{coupon,replaceId:order.orderId,
   purchaseMode:order.purchaseMode});
});$('lic-close-qr').addEventListener('click',()=>closePayment(false));init().catch(e=>message(e.message,true))});
 globalThis.License={xmlRpc:(name,params)=>rpc(name,params||{}),status,check,autoNameFromGdt,mstConsentStatus,mstConsentDecide,rememberSignedInMst,requireMstAllowed,markTaxPasswordUpdated,purchaseData365:()=>buy('DATA365',$('tendooData365Buy'),true),closeInlinePayment:()=>closePayment(true),canUse:()=>!!license?.allowed,refreshQuota,getState:()=>license,getProfiles:()=>[...profileMsts],getAllowedProfiles:()=>[...profileAllowedMsts],getProfileLabels:()=>({...profileNames}),getSharedMsts:()=>[...sharedProfileMsts]};
})();