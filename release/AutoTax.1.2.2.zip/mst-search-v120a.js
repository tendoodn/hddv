/* AutoTax V1.1.35: Web-style single-field MST input + integrated list. */
(()=>{
'use strict';
const $=id=>document.getElementById(id);
function init(){
 const native=$('demoGdtMst'),search=$('demoGdtMstSearch'),typed=$('demoGdtMstNew');
 if(!native||!typed)return;
 // Reuse the existing manual MST input as the ONE visible search/edit field.
 // Keep the original native select for the tax-login backend's change event.
 if(search)search.hidden=true;
 typed.hidden=false;
 typed.removeAttribute('inputmode'); // Tax IDs and Vietnamese names must both be searchable.
 typed.inputMode='text';
 typed.placeholder='Nhập MST hoặc tìm theo tên hồ sơ';
 const wrapper=document.createElement('div');
 wrapper.className='demo-gdt-mst-unified';
 native.parentNode.insertBefore(wrapper,typed);
 wrapper.append(typed);
 const menu=document.createElement('div');
 menu.id='demoGdtMstQuickResults';menu.className='demo-gdt-mst-quick-results';
 menu.setAttribute('role','listbox');menu.hidden=true;
 wrapper.append(menu);
 const normal=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/đ/g,'d').toLocaleLowerCase('vi-VN');
 const granted=()=>new Set(globalThis.License?.getAllowedProfiles?.()||[]);
 function close(){
  menu.hidden=true;
 }
 function choose(value){
  typed.value=value;
  native.value=value;
  native.dispatchEvent(new Event('change',{bubbles:true}));
  close();
 }
 function draw(showAll=false){
  menu.replaceChildren();
  const q=showAll?'':normal(typed.value.trim());
  const notes=globalThis.License?.getProfileNotes?.()||{};
  const allowed=granted();
  let count=0;
  for(const option of native.options){
   if(!option.value)continue;
   const raw=option.value+' '+option.textContent+' '+(notes[option.value]||option.title||'');
   if(q&&!normal(raw).includes(q))continue;
   const button=document.createElement('button');button.type='button';
   button.className='demo-gdt-mst-result';
   button.setAttribute('role','option');
   button.setAttribute('aria-selected',String(typed.value===option.value));
   const label=document.createElement('span');label.className='demo-gdt-mst-result-label';
   const number=document.createElement('strong');number.textContent=option.value;
   const displayName=String(option.textContent||'').replace(option.value,'').replace(/^\s*[–—-]\s*/,'').trim();
   const name=document.createElement('small');name.textContent=displayName;
   label.append(number);if(displayName)label.append(name);
   const status=document.createElement('span');
   const grant=allowed.has(option.value);
   status.className='demo-gdt-mst-status '+(grant?'is-granted':'is-denied');
   status.textContent=grant?'✓':'✕';
   status.setAttribute('aria-label',grant?'MST được cấp quyền':'MST chưa cấp quyền');
   button.append(label,status);
   button.title=notes[option.value]||option.title||option.textContent;
   button.addEventListener('click',()=>choose(option.value));
   menu.append(button);
   if(++count>=70)break;
  }
  if(!count){
   const info=document.createElement('small');
   info.className='demo-gdt-mst-empty';
   info.textContent=typed.value.trim()
    ?'Không tìm thấy hồ sơ. Bạn có thể nhập trực tiếp MST mới vào ô phía trên.'
    :'Chưa có MST đã lưu. Nhập MST vào ô phía trên để đăng nhập.';
   menu.append(info);
  }
 }
 function open(showAll=false){
  if(typed.disabled||native.disabled)return;
  menu.hidden=false;draw(showAll);
 }
 typed.addEventListener('focus',()=>open(true));
 typed.addEventListener('input',()=>open(false));
 typed.addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();close()}
  else if(e.key==='ArrowDown'){e.preventDefault();open(true);menu.querySelector('button')?.focus()}
  else if(e.key==='Enter'&&!menu.hidden){
   e.preventDefault();e.stopPropagation();
   // A complete number is a legitimate NEW MST; don't force a saved result.
   const number=typed.value.replace(/\D/g,'');
   if(/^(?:\d{10}|\d{12}|\d{13})$/.test(number))close();
   else menu.querySelector('.demo-gdt-mst-result:not([hidden])')?.click();
  }
 });
 menu.addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();close();typed.focus()}
  if(e.key==='Enter'&&e.target.matches('button')){e.preventDefault();e.target.click()}
 });
 document.addEventListener('pointerdown',event=>{
  if(!wrapper.contains(event.target)&&!menu.hidden)close();
 },{capture:true});
 native.addEventListener('change',()=>{if(native.value)typed.value=native.value;close()});
 new MutationObserver(()=>{if(!menu.hidden)draw()})
  .observe(native,{childList:true});
 document.addEventListener('autotax-mst-profiles',()=>{if(!menu.hidden)draw()});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
else init();
})();