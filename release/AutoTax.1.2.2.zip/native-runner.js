// DEMO: xử lý gốc ngay trong Side Panel; dùng phiên cổng Thuế đã xác thực trong Add-on.
// 1 lần bấm "Tải dữ liệu": tra cứu từng tháng → (nếu cần) tải chi tiết từng hóa đơn → zip XML/HTML/PDF từng tháng
// → Excel bảng kê. Mọi xử lý trong bộ nhớ tiện ích, file ghi vào Downloads.
let stopFlag = false;
let busy = false;

const safeName = (s) => (s || '').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').replace(/\s+/g, ' ').replace(/^[\s.]+|[\s.]+$/g, '').slice(0, 120);
const waitText = ({ secs, attempt, max, rate }) => (rate
  ? `cổng thuế báo gửi quá nhiều yêu cầu (429), tự thử lại sau ${secs} giây (lần ${attempt}/${max})`
  : `cổng thuế chưa trả lời, đã chờ ${secs} giây${max > 1 ? ` (lần ${attempt}/${max})` : ''}`);
const isoOf = (vn) => vn.split('/').reverse().join('-'); // dd/mm/yyyy → yyyy-mm-dd
const DOWNLOAD_ROOT = 'HoaDon'; // Legacy naming only; files now go directly to user-selected folder.
const ZIP_PART_BYTES = 40 * 1024 * 1024; // ~40 MB/zip: data URL base64 còn ~55 MB, dưới giới hạn 64 MB của tin nhắn Chrome

const HISTORY_KEY = 'autotax_invoice_history_v1';
const HISTORY_LIMIT = 20000;
const invoiceHistoryKey = (r, mst) => [mst || '', r.kind || '', r.form || '', r.khmshdon || '', r.khhdon || '', r.shdon || ''].join('|');
// Team-first, idempotent counted-invoice authorization is handled by autotax_claim_invoice_quota_v118.
// MST mode does not deduct invoice quota; repeated reads use backend deduplication.
async function updateInvoiceHistory(rows, mst, mode, formats = {}) {
  if (!rows?.length) return;
  const stored = await chrome.storage.local.get(HISTORY_KEY);
  const db = stored[HISTORY_KEY] || { version: 1, records: {} };
  const now = new Date().toISOString();
  for (const r of rows) {
    const key = invoiceHistoryKey(r, mst);
    const old = db.records[key] || {};
    const rec = {
      key, mst: mst || '', kind: r.kind || '', form: r.form || '',
      invoiceNo: String(r.shdon ?? ''), series: r.khhdon || '', template: r.khmshdon || '',
      sellerTax: r.nbmst || '', sellerName: r.nbten || '',
      buyerTax: r.nmmst || '', buyerName: r.nmten || '',
      date: r.tdlap || '', status: r.tthai ?? null, processing: r.ttxly ?? null,
      firstSeenAt: old.firstSeenAt || now,
      lastSearchedAt: mode === 'searched' ? now : (old.lastSearchedAt || ''),
      searchedCount: (old.searchedCount || 0) + (mode === 'searched' ? 1 : 0),
      downloadedAt: mode === 'downloaded' ? now : (old.downloadedAt || ''),
      downloadedFormats: mode === 'downloaded' ? [...new Set([...(old.downloadedFormats || []), ...Object.keys(formats[invoiceHistoryKey(r, mst)] || formats).filter(k => (formats[invoiceHistoryKey(r, mst)] || formats)[k])])] : (old.downloadedFormats || []),
    };
    db.records[key] = rec;
  }
  const entries = Object.entries(db.records).sort((a,b) => (b[1].lastSearchedAt || b[1].firstSeenAt).localeCompare(a[1].lastSearchedAt || a[1].firstSeenAt));
  db.records = Object.fromEntries(entries.slice(0, HISTORY_LIMIT));
  await chrome.storage.local.set({ [HISTORY_KEY]: db });
}

async function save(bytes,mime,filename){
 if(window.NativeZipBatch?.capturing())return window.NativeZipBatch.capture(filename,bytes,mime);
 if(!window.AutoTaxDownloadFolder)throw Error('Chưa khởi tạo bộ lưu thư mục.');
 return window.AutoTaxDownloadFolder.save(filename,bytes,mime);
}

async function assertPackageAccessForMst(mst) {
  const stored=await chrome.storage.local.get('autotax_license_session_v1');
  const token=stored.autotax_license_session_v1?.access_token;
  if(!token)throw new Error('Vui lòng đăng nhập AutoTax và cấu hình hồ sơ MST.');
  const base='https://ucqqjdsoyvvaxswzbhaw.supabase.co';
  const key='sb_publishable_7zUjUap6EkHJZ0Gp12vesw_UY-yB7jJ';
  const headers={apikey:key,Authorization:'Bearer '+token,'Content-Type':'application/json'};
  // A server-side READ-ONLY check against the ACTUAL GDT session MST.
  // Never auto-assign unknown MSTs just because a package has spare capacity.
  const response=await fetch(base+'/rest/v1/rpc/autotax_verify_session_mst_v118',{
    method:'POST',headers,body:JSON.stringify({p_mst:mst})
  });
  const result=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(result.message||
    'Không kiểm tra được danh sách hồ sơ MST. Tìm kiếm đã bị khóa.');
  if(!result.allowed){
    const messages={
      mst_profile_not_configured:'Chưa cấu hình MST '+(mst||'đang đăng nhập')+
        '. Hãy thêm MST này trong danh sách hồ sơ của AutoTax.',
      mst_capacity_reduced:'MST này vượt quá số hồ sơ còn hiệu lực trong gói.',
      mst_package_expired:'Gói MST đã hết hạn.',
      invoice_package_required:'Gói số tờ không còn quyền tra cứu.',
      invalid_mst:'MST của phiên đăng nhập cổng Thuế không hợp lệ.'
    };
    throw new Error(messages[result.reason]||
      'MST đang đăng nhập không được phép tra cứu với tài khoản AutoTax.');
  }
  return {mode:result.mode||'mst',remaining:null};
}
async function claimInvoiceQuota(rows,mst,send){
 const scanQuota=globalThis.AutoTaxAccountFlow.createScanQuotaCounter();
 // A successful scan can have zero invoices and must still report zero charges.
 if(!rows.length){
  send({type:'log',level:'ok',text:scanQuota.summary()});
  return rows;
 }
 const stored=await chrome.storage.local.get('autotax_license_session_v1');
 const token=stored.autotax_license_session_v1?.access_token;
 if(!token)throw Error('Phiên AutoTax đã hết hạn. Đăng nhập lại để xác minh lượt tờ.');
 const base='https://ucqqjdsoyvvaxswzbhaw.supabase.co';
 const key='sb_publishable_7zUjUap6EkHJZ0Gp12vesw_UY-yB7jJ';
 const accepted=[];
 const identity=i=>JSON.stringify([i.mst,i.direction,i.form_code,i.series,i.invoice_number]);
 // Deduplicate transport only; never bypass server authorization or charge decisions.
 // Stable authenticated account identity is taken from the JWT by Supabase;
 // the display username is not a safe primary key because it can be renamed.
 const unique=new Map();
 for(const row of rows){
  const item={mst,direction:row.kind||'',
   form_code:(row.form||'')+':'+(row.khmshdon||''),
   series:row.khhdon||'',invoice_number:String(row.shdon??'')};
  const k=identity(item);
  if(!unique.has(k))unique.set(k,{item,row});
 }
 const unseen=[...unique.values()];
 try{
 for(let n=0;n<unseen.length;n+=250){
  const chunk=unseen.slice(n,n+250);
  const items=chunk.map(x=>x.item);
  const response=await fetch(base+'/rest/v1/rpc/autotax_claim_invoice_quota_v118',{
   method:'POST',headers:{apikey:key,Authorization:'Bearer '+token,'Content-Type':'application/json'},
   body:JSON.stringify({p_items:items})
  });
  const result=await response.json().catch(()=>({}));
  if(!response.ok)throw Error('Không xác minh được số lượt đã mua: '+(result.message||response.status));
  const allowed=new Set((result.allowed_items||[]).map(identity));
  for(let i=0;i<chunk.length;i++)if(allowed.has(identity(items[i])))accepted.push(chunk[i].row);
  if(Number(result.denied||0)>0)document.dispatchEvent(new Event('autotax-invoice-quota-exhausted'));
  scanQuota.add(result);
  send({type:'log',level:Number(result.denied||0)?'warn':'ok',
   text:'Lô xác minh: trừ '+Number(result.deducted||0)+' lượt số tờ'+
    ' (nhóm: '+Number(result.team_deducted||0)+', cá nhân: '+Number(result.personal_deducted||0)+'); '+
    Number(result.previously_deducted||0)+' hóa đơn đọc lại không trừ; '+
    Number(result.recorded_without_charge||0)+' hóa đơn dùng MST không trừ số tờ; '+
    Number(result.denied||0)+' thiếu quyền hoặc lượt.'});
 }
 }finally{
  // Report already committed counts even if another batch fails or is stopped.
  send({type:'log',level:'ok',text:scanQuota.summary()});
 }
 return accepted;
}
async function runJob({ tuNgay, denNgay, kinds, forms, filters, formats, adjOnly, sheets = {}, tendoo = null }, send, linkSku) {
  stopFlag = false;
  const shouldStop = () => stopFlag;
  const profile = await HDDT.getSessionInfo();
  if (!profile.ready) throw new Error('Chưa đăng nhập hoadondientu – hãy đăng nhập rồi bấm ↻');
  const packageAccess = await assertPackageAccessForMst(profile.mst);
  // Cache is read only AFTER server authorization; quota claims remain unchanged.
  const storedSession=(await chrome.storage.local.get('autotax_license_session_v1')).autotax_license_session_v1;
  const detailCache=window.AutoTaxInvoiceCache;
  const detailScope={userId:String(storedSession?.user?.id||''),mst:String(profile.mst||'')};
  const dir = `${DOWNLOAD_ROOT}/${safeName([profile.mst, profile.company].filter(Boolean).join(' – ')) || 'CongTy'}/${isoOf(tuNgay)}_${isoOf(denNgay)}`;

  window.NativeZipBatch?.cancel();window.NativeZipBatch?.begin(profile.mst,profile.company,tuNgay,denNgay);

  // 1. Tra cứu
  // Hóa đơn điện tử tra theo tháng; máy tính tiền chia đoạn tối đa 10 ngày, mỗi đoạn có CAPTCHA riêng.
  // V3: số ngày MTT được cố định ở HDDT.FORMS.mtt.days = 10, không ghi đè từ storage.
  const parts = forms.map((f) => `${HDDT.splitFor(f, tuNgay, denNgay).length} ${HDDT.FORMS[f].days ? `đoạn ${HDDT.FORMS[f].days} ngày` : 'tháng'}`);
  send({ type: 'status', text: `Đang tra cứu ${parts.join(' + ')}…` });
  const res = await HDDT.search({ tuNgay, denNgay, kinds, forms, filters, shouldStop,
    onProgress: (p) => send({ type: 'status', text: `${p.label}: đã đọc ${p.count} hóa đơn` }),
    onWarn: (text) => send({ type: 'log', level: 'warn', text }),
    // Cổng chậm: đếm giây ngay trên dòng trạng thái để người dùng biết vẫn đang chờ, không phải treo
    onWait: (w) => send({ type: 'status', text: `${w.label}: ${waitText(w)}${w.slow && !w.rate ? ' (tra máy tính tiền thường chậm, chờ tối đa 90 giây)' : ''}` }) });
  // If the GDT profile response has no name, infer it only from invoice
  // parties whose own MST is exactly the signed-in GDT MST.
  if(!profile.company){
   const names=new Map(),digits=v=>String(v||'').replace(/\D/g,'');
   for(const r of res.rows||[]){
    const same=r.kind==='purchase'?digits(r.nmmst)===digits(profile.mst):
      digits(r.nbmst)===digits(profile.mst);
    if(!same)continue;
    const name=String((r.kind==='purchase'?r.nmten:r.nbten)||'')
      .replace(/\s+/g,' ').trim();
    if(name.length>=3&&name.length<=120&&/[\p{L}]/u.test(name)&&
       !/^(khách lẻ|khach le)$/i.test(name))
      names.set(name,(names.get(name)||0)+1);
   }
   const probable=[...names.entries()].sort((a,b)=>b[1]-a[1])[0]?.[0];
   if(probable)send({type:'mst-name',mst:profile.mst,name:probable,
     source:'Tên người mua/bán có MST trùng phiên Thuế'});
  }
  let rows = res.rows;
  // Chỉ HĐ thay thế / điều chỉnh / hủy: lọc theo tthai ngay sau tra cứu, trước khi tải chi tiết (tthai 1 = hóa đơn mới)
  if (adjOnly) {
    rows = rows.filter((r) => r.tthai && Number(r.tthai) !== 1);
    send({ type: 'log', level: 'ok', text: `Chỉ lấy hóa đơn thay thế/điều chỉnh/hủy: ${rows.length}/${res.rows.length} hóa đơn` });
  }
  // A counted-invoice account may read arbitrary MSTs; each new invoice is
  // authorized by the server, including Excel-only search and repeated runs.
  // Read history is shared across modes. MST reads cost zero but must be remembered.
  rows=await claimInvoiceQuota(rows,profile.mst,send);
  await updateInvoiceHistory(rows, profile.mst, 'searched');
  const count = (k, f) => rows.filter((r) => r.kind === k && (!f || r.form === f)).length;
  // Mỗi loại 1 phần; chọn cả 2 hình thức thì tách thêm điện tử / máy tính tiền
  const byForm = (k) => (forms.length > 1 ? ` (${forms.map((f) => `${f === 'mtt' ? 'máy tính tiền' : 'điện tử'} ${count(k, f)}`).join(', ')})` : '');
  const found = kinds.map((k) => `${HDDT.KINDS[k].act} ${count(k)}${byForm(k)}`).join('; ');
  send({ type: 'log', level: 'ok', text: `Tìm thấy ${rows.length} hóa đơn: ${found}` });
  send({ type: 'summary', total: rows.length, purchase: count('purchase'), sold: count('sold') });
  if (!rows.length) {window.NativeZipBatch?.cancel();return send({ type: 'done', total: 0, saved: 0, errors: 0, stopped: res.stopped, dir:window.AutoTaxDownloadFolder?.label||'' });}

  // 2. Tra từng hóa đơn và lưu file XML/HTML/PDF riêng lẻ theo loại, không ZIP.
  // Hóa đơn không mã (ttxly 6): cổng không lưu XML gốc → chỉ gọi API chi tiết khi cần dòng hàng hóa cho Excel.
  // PDF gốc: chỉ nhận file PDF thực từ link nhà phát hành đã được cấp quyền.
  // Trang yêu cầu CAPTCHA/đăng nhập hoặc chỉ có XML phải có báo cáo thiếu PDF, KHÔNG dựng giả.
  // Excel "Mua vào" / "Bán ra" needs raw item codes from each invoice, even if
  // the user did not select "Chi tiết sản phẩm" or upload any SKU catalog.
  // Always prefer source XML for invoice metadata, including SKU, issuer lookup
  // link and lookup code. Export original XML bytes only when XML is selected.
  const needProductLines = true;
  const needDetail = true;
  const details = new Map();
  const issuerSamples=new Map();
  let errors = 0, saved = 0, done = 0;
  const downloadedInZip=new Map(), formatsInZip={};
  if (needDetail && !res.stopped) {
    const order = rows.filter((r) => needProductLines || formats.pdf || r.ttxly !== 6)
      .sort((a, b) => `${a.kind}|${a.month}|${a.form}`.localeCompare(`${b.kind}|${b.month}|${b.form}`));
    let bucket=null,files=[],bytes=0,activeInvoiceKey='',bucketInvoiceFormats=new Map();
    const flush=async()=>{
      if(!files.length)return;
      const succeeded=new Set();
      for(const file of files){
       try{
        await save(file.data,'application/octet-stream',`${dir}/${file.name}`);
        if(file.owner)succeeded.add(file.owner);
        saved++;
       }catch(error){
        errors++;
        send({type:'log',level:'error',text:'Không lưu được '+file.name+': '+error.message});
       }
      }
      if(succeeded.size){
       const savedRows=rows.filter(row=>succeeded.has(invoiceHistoryKey(row,profile.mst)));
       const formatsByRow=Object.fromEntries([...bucketInvoiceFormats].filter(([key])=>succeeded.has(key)));
       for(const row of savedRows)downloadedInZip.set(invoiceHistoryKey(row,profile.mst),row);
       Object.assign(formatsInZip,formatsByRow);
      }
      files=[];bytes=0;bucketInvoiceFormats=new Map();
    };
    const add=(name,data)=>{
      files.push({name,data,owner:activeInvoiceKey});
      bytes+=typeof data==='string'?new TextEncoder().encode(data).length:data.length;
    };
    for (const row of order) {
      if (stopFlag) break;
      const b = `${row.kind}|${row.month}`;
      if (b !== bucket) { await flush(); bucket = b; }
      if (bytes > ZIP_PART_BYTES) await flush();
      // Bán cho khách lẻ thường không có MST người mua → "KhachLe"
      activeInvoiceKey=invoiceHistoryKey(row,profile.mst);
      // Prefer the publisher's digital signing date; fall back to invoice issue date.
      let base = '';
      const sub = HDDT.FORMS[row.form].ep === 'sco-query' ? 'MayTinhTien/' : '';
      try {
        const cachedInv=await detailCache?.get(detailScope,row);
        const inv=cachedInv||await HDDT.fetchInvoice(row, shouldStop,
          (w) => send({ type: 'status', text: `Đang tải chi tiết ${done + 1}/${order.length}: ${waitText(w)}` }));
        if(!cachedInv&&!shouldStop())void detailCache?.put(detailScope,row,inv).catch(()=>{});
        const signed=inv.head?.seller?.time||inv.head?.signatureTime||'';
        const publishDate=Report.dateVN(signed||inv.head?.nlap||row.tdlap).split('/').join('');
        base=safeName(`${row.kind==='purchase'?'MuaVao':'BanRa'}_${row.khhdon}_${row.shdon}_${publishDate||'KhongRoNgay'}`);
        // head (chữ ký số, ngày ký, hình thức thanh toán…) dùng cho DS hóa đơn + Kiểm tra rủi ro HĐ; dòng hàng chỉ giữ khi cần
        details.set(row.key, { source: inv.source, head: inv.head, xmlFields:inv.xmlFields||{},
          lines: formats.excel ? inv.lines : (inv.lines||[]).map(line=>({ma:line.ma,ten:line.ten})),
          ...(formats.excel?{fees:inv.fees}:{}) });
        const sample=window.AutoTaxIssuerReference?.sample(row,inv,profile.mst);
        if(sample)issuerSamples.set(sample.session_mst+'|'+sample.form_code+'|'+
          sample.series+'|'+sample.invoice_number,sample);
        const invoiceFormats = {};
        if (inv.source === 'xml') {
          // Nguyên bytes gốc của cổng (không giải mã/mã hóa lại) để mở được bằng phần mềm của Cục Thuế
          if (formats.xml && inv.xml) { add(`XML/${sub}${base}.xml`, inv.xml); invoiceFormats.xml = true; }
          // HTML: chỉ ghi nhận khi thực sự thêm được ít nhất một tệp HTML/tài nguyên vào ZIP.
          if (formats.html) for (const [n, data] of Object.entries(inv.files || {})) if (!/\\.xml$/i.test(n)) {
            add(`HTML/${sub}${base}/${n}`, data); invoiceFormats.html = true;
          }
        } else if (row.ttxly !== 6 && (formats.xml || formats.html)) {
          send({ type: 'log', level: 'warn', text: `${row.khhdon}-${row.shdon}: cổng không trả được XML gốc (chỉ có trong Excel${formats.pdf ? ', PDF' : ''})` });
        }
        if (formats.pdf) {
          // Never regenerate if GDT's original downloaded archive ALREADY
          // includes a real PDF. Preserve its exact bytes and source folder.
          const sourcePdf=Object.entries(inv.files||{}).find(([name,data])=>
            /\.pdf$/i.test(name)&&data?.length>=5&&
            data[0]===37&&data[1]===80&&data[2]===68&&data[3]===70&&data[4]===45);
          if(sourcePdf){
            add(`PDF_Nguon_Tu_Cong_Thue/${sub}${base}.pdf`,sourcePdf[1]);
            invoiceFormats.pdf=true;
            send({type:'log',level:'ok',text:`${row.khhdon}-${row.shdon}: đã lưu PDF thực có trong gói cổng Thuế.`});
          }
          if(!invoiceFormats.pdf){
          const source=HDDT.originalLookup(row,inv.head);
          const decision=window.IssuerPortals?.route(source)||{
            shouldReconstruct:!(source.link&&source.code),
            directPdf:/\\.pdf$/i.test(String(source.link||''))
          };
          let originalError='';
          // Try a genuine PDF URL first, including signed download URLs
          // where the security token is already carried in the original link.
          if(source.link&&decision.directPdf){
            try{
              const result=await chrome.runtime.sendMessage({
                type:'fetch-issuer-pdf',url:source.link
              });
              if(!result?.ok||!result.pdfBase64)
                throw Error(result?.error||'Nhà phát hành chưa trả PDF.');
              const pdf=Uint8Array.from(atob(result.pdfBase64),ch=>ch.charCodeAt(0));
              if(pdf.length<5||pdf[0]!==37||pdf[1]!==80||pdf[2]!==68||
                pdf[3]!==70||pdf[4]!==45)throw Error('Không phải PDF.');
              add(`PDF_Goc_Nha_Phat_Hanh/${sub}${base}.pdf`,pdf);
              invoiceFormats.pdf=true;
            }catch(e){originalError=e.message||String(e)}
          }
          if(!invoiceFormats.pdf){
            // If the original failed, keep issuer-link/code for later assisted
            // retrieval even though the current download will contain a
            // clearly marked rebuilt PDF. Do not launch mass CAPTCHA tabs.
            // When XML identifies Viettel but omits the search URL, use only
            // Viettel's known official lookup page. CAPTCHA remains user-solved.
            const assistedLink=source.link||(
              /(viettel|s[ -]?invoice)/i.test(source.name||'')
              ?window.IssuerPortals?.sources?.find(x=>x.id==='viettel')?.portal:'');
            if(assistedLink&&source.code){
              try{
                const queued=await chrome.runtime.sendMessage({
                  type:'issuer-queue-add',link:assistedLink,code:source.code,
                  ownerMst:profile.mst,
                  sellerMst:inv.head?.nbmst||row.nbmst||'',
                  buyerMst:inv.head?.nmmst||row.nmmst||'',
                  invoiceNumber:inv.head?.shdon||String(row.shdon||''),
                  invoice:base
                });
                if(!queued?.ok)send({type:'log',level:'warn',
                  text:'Không đưa được hóa đơn vào danh sách tra PDF gốc: '+(queued?.error||'lỗi không rõ')});
              }catch(e){send({type:'log',level:'warn',
                text:'Chưa lưu được yêu cầu tra PDF gốc: '+(e.message||String(e))})}
            }
            // The Add-on is intentionally less strict than the Web Tax PDF
            // button: genuine PDF preferred, rebuild whenever absent/blocked.
            // NEVER label the fallback representation as an original.
            try{
              const generated=await Pdf.buildInvoicePdf(row,inv,source);
              if(!generated||generated.length<5||generated[0]!==37||
                 generated[1]!==80||generated[2]!==68||generated[3]!==70||
                 generated[4]!==45)throw Error('PDF dựng không hợp lệ.');
              add(`PDF_Dung_Lai_Tu_CQT_Khong_Phai_Goc/${sub}${base}.pdf`,generated);
              invoiceFormats.pdf=true;
              send({type:'log',level:'warn',
                text:`${row.khhdon}-${row.shdon}: không lấy được PDF gốc (${originalError||'chưa có URL tải trực tiếp'}), đã xuất PDF dựng lại KHÔNG PHẢI GỐC.`});
              const provenance=[
                'AutoTax PDF goc -> fallback tu du lieu CQT, KHONG PHAI GOC',
                'MST ben ban: '+(row.nbmst||''),
                'Ky hieu / so: '+(row.khhdon||'')+' / '+(row.shdon||''),
                'Link tra cuu: '+(source.link||'Khong co'),
                'Ma tra cuu: '+(source.code||'Khong co'),
                'Ly do khong tai PDF goc: '+(originalError||'Khong co URL tai PDF truc tiep')
              ];
              add(`PDF_Dung_Lai_Tu_CQT_Khong_Phai_Goc/${sub}${base}_NGUON.txt`,
                new TextEncoder().encode(provenance.join('\n')));
            }catch(e){originalError=e.message||String(e)}
          }
          if(!invoiceFormats.pdf){
            // The PDF rebuild itself also failed; report the invoice as missing.
            errors++;
            const guide=[
             'AutoTax V1.1 - CHUA TAI DUOC PDF GOC',
             'Thu PDF goc truoc. Neu khong lay duoc thi dung PDF tu CQT co nhan KHONG PHAI GOC.',
             'MST ben ban: '+(row.nbmst||''),
             'Ky hieu/so: '+(row.khhdon||'')+' / '+(row.shdon||''),
             'Nha phat hanh: '+(source.name||'Chua xac dinh'),
             'Link tra cuu: '+(source.link||'Chua co trong du lieu'),
             'Ma tra cuu/bao mat: '+(source.code||'Chua co trong XML'),
             'Ly do: '+(originalError||'Khong lay duoc PDF goc va khong dung duoc PDF thay the'),
             'Mo duong dan tra cuu tren hoa don de tai PDF goc khi cong yeu cau xac thuc.'
            ];
            add(`PDF_Chua_Lay_Duoc_Goc/${sub}${base}.txt`,new TextEncoder().encode(guide.join('\n')));
            send({type:'log',level:'warn',
              text:`${row.khhdon}-${row.shdon}: đã có link/mã nhưng chưa lấy được PDF gốc. Xem PDF_Chua_Lay_Duoc_Goc.`});
          }
          } // no PDF in GDT archive: try issuer source and flagged fallback
        }
        // Lưu chính xác các định dạng hóa đơn đã đóng góp tệp vào ZIP.
        if (Object.values(invoiceFormats).some(Boolean)) bucketInvoiceFormats.set(invoiceHistoryKey(row, profile.mst), invoiceFormats);
      } catch (e) {
        if (e.status === 401) throw e;
        if (stopFlag) break; // Dừng: request đang chờ bị hủy, không tính là lỗi
        errors++;
        const mst = row.kind === 'purchase' ? row.nbmst : row.nmmst;
        send({ type: 'log', level: 'error', text: `Không tải được hóa đơn ${row.khhdon}-${row.shdon} (${mst ? `MST ${mst}` : 'khách lẻ'}): ${e.message}` });
      }
      send({ type: 'progress', done: ++done, total: order.length });
      // HDDT.get() already spaces GDT requests; do not wait twice per invoice.
    }
    await flush();
    if(issuerSamples.size){
      try{
        const issuerStats=await window.AutoTaxIssuerReference.submit([...issuerSamples.values()],storedSession);
        send({type:'log',level:'ok',text:'Chân PDF dựng: '+issuerStats.registered+
          ' mẫu nhà cung cấp được cập nhật; '+issuerStats.skipped+
          ' mẫu giữ nguyên (đủ 5/5 hoặc dữ liệu không tốt hơn); '+issuerStats.rejected+
          ' không khớp quyền đọc.'});
      }catch(error){
        send({type:'log',level:'warn',text:'Đã đọc hóa đơn, chưa ghi được mẫu tham chiếu nhà phát hành: '+error.message});
      }
    }
    window.AutoTaxXmlColumns?.registerFields?.([...details.values()].flatMap(d=>Object.keys(d.xmlFields||{})));
    const xmlRead=[...details.values()].filter(d=>d.source==='xml').length;
    const skuRead=[...details.values()].filter(d=>(d.lines||[]).some(line=>String(line.ma||'').trim())).length;
    const lookupRead=[...details.values()].filter(d=>d.head?.lookup?.code||d.head?.lookup?.link).length;
    const xmlColumns=new Set([...details.values()].flatMap(d=>Object.keys(d.xmlFields||{}))).size;
    send({type:'log',level:'ok',text:
      'Đã phân tích XML/chi tiết: '+xmlRead+'/'+rows.length+' có XML gốc, '+
      skuRead+' có mã hàng hóa, '+lookupRead+' có dữ liệu tra cứu, '+
      xmlColumns+' tên cột XML (bao gồm trường trống). '+
      'Chỉ lưu tệp XML nếu người dùng chọn tải XML.'});
    const khongMa = rows.filter((r) => r.ttxly === 6).length;
    if (khongMa && (formats.xml || formats.html)) send({ type: 'log', text: `${khongMa} hóa đơn không mã (ký hiệu bắt đầu bằng K): cổng thuế không lưu file XML/HTML gốc nên chỉ có trong Excel – bình thường, không phải lỗi` });
  }

  // 3. Sheet HĐ thay thế / điều chỉnh: cần dòng hàng của cả 2 hóa đơn → tải thêm HĐ thay thế/điều chỉnh chưa có chi tiết
  // và hóa đơn gốc (kể cả gốc nằm ngoài khoảng ngày). Thường chỉ vài hóa đơn nên tải luôn, tuần tự như bước 2.
  const originals = new Map();
  if (formats.excel && sheets.adjust && !stopFlag && !res.stopped) {
    const adj = rows.filter((r) => Report.isAdjusting(r));
    const { unique: byRef, ambiguous: ambiguousRefs } = Report.indexByRef(rows);
    const todo = [];
    for (const r of adj) {
      if (!details.get(r.key)?.lines) todo.push({ row: r, get: () => HDDT.fetchInvoice(r, shouldStop), put: (inv) => details.set(r.key, { source: inv.source, head: inv.head, lines: inv.lines, fees: inv.fees }) });
      const k = Report.refKey(r.gocRef), inRange = byRef.get(k);
      if (ambiguousRefs.has(k)) { originals.set(k, { ambiguous: true }); continue; }
      if (inRange ? details.get(inRange.key)?.lines || todo.some((t) => t.row === inRange) : originals.has(k)) continue;
      if (inRange) todo.push({ row: inRange, get: () => HDDT.fetchInvoice(inRange, shouldStop), put: (inv) => details.set(inRange.key, { source: inv.source, head: inv.head, lines: inv.lines, fees: inv.fees }) });
      else { originals.set(k, null); todo.push({ row: r, gocOf: true, originalKey: k, get: () => HDDT.fetchOriginal(r, shouldStop), put: (inv) => originals.set(k, inv) }); }
    }
    let i = 0;
    for (const t of todo) {
      if (stopFlag) break;
      send({ type: 'status', text: `Đang tải hóa đơn gốc để so sánh HĐ thay thế/điều chỉnh ${++i}/${todo.length}` });
      try { t.put(await t.get()); } catch (e) {
        if (e.status === 401) throw e;
        if (stopFlag) break;
        if (t.gocOf && t.originalKey) originals.set(t.originalKey, { error: e.message || 'Lỗi không xác định' });
        const ref = t.gocOf ? t.row.goc : `${t.row.khhdon}-${t.row.shdon}`;
        send({ type: 'log', level: 'warn', text: `Không tải được hóa đơn ${t.gocOf ? 'gốc ' : ''}${ref}: ${e.message}` });
      }
      // Shared GDT queue applies its own retry and cooldown for originals.
    }
  }

  // 3b. Sheet Kiểm tra rủi ro MST: đối chiếu MST người bán (mua vào) / người mua (bán ra) với danh sách công khai sử dụng hóa đơn
  // không hợp pháp của cổng (cache trên máy, tra gộp nhiều MST / request). Lỗi → chỉ cảnh báo, Excel vẫn lưu.
  let illegal = null;
  if (formats.excel && sheets.seller && !stopFlag && !res.stopped) {
    const msts = rows.map((r) => (r.kind === 'purchase' ? r.nbmst : r.nmmst)).filter(Boolean);
    try {
      illegal = await HDDT.illegalCheck(msts, { shouldStop, onStatus: (text) => send({ type: 'status', text }) });
      const hits = Object.values(illegal).filter((e) => e.recs.length).length;
      send({ type: 'log', level: hits ? '' : 'ok', text: hits ? `${hits} người bán/người mua có tên trong danh sách sử dụng hóa đơn không hợp pháp của Cục Thuế – xem cột "Kiểm tra rủi ro MST" trong Excel` : 'Không người bán/người mua nào có tên trong danh sách sử dụng hóa đơn không hợp pháp của Cục Thuế' });
    } catch (e) {
      if (e.status === 401) throw e;
      if (!stopFlag) send({ type: 'log', level: 'warn', text: `Không đối chiếu được danh sách công khai hóa đơn không hợp pháp: ${e.message}` });
    }
  }

  // 4. Excel bảng kê (kể cả khi đã bấm Dừng: lưu với dữ liệu đã có)
  if (formats.excel) {
    const name = `${dir}/BangKe_${kinds.map((k) => HDDT.KINDS[k].folder).join('-')}_${isoOf(tuNgay)}_${isoOf(denNgay)}.xlsx`;
    const productCodeInvoiceCount = rows.filter(row=>(details.get(row.key)?.lines||[]).some(line=>String(line.ma??'').trim())).length;
    send({ type: 'log',level: productCodeInvoiceCount?'ok':'warn', text:
      'Mã hàng hóa gốc (XML/JSON): '+productCodeInvoiceCount+'/'+rows.length+
      ' hóa đơn có mã đọc được; hóa đơn không ghi mã hoặc không tải được chi tiết sẽ để trống cột Mã hàng hóa.' });
    const book = Report.buildSheets(rows, details, { withLines: formats.lines, withPdf: formats.pdf, sheets, originals, illegal, tuNgay, denNgay, mst: profile.mst, company: profile.company,
      kinds, adjOnly, skipped: res.skipped || [], stopped: stopFlag || res.stopped });
    await save(await window.AutoTaxFastWorkbook.build(book), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name);
    // Excel không đánh dấu đã tải và không trừ quota.
    // 1 dòng: số sheet + tóm tắt rủi ro (chỉ nêu khi có cảnh báo / lưu ý)
    const risk = book.find((x) => x.summary)?.summary;
    const flags = risk ? [risk.bad && `${risk.bad} hóa đơn bị cảnh báo`, risk.warn && `${risk.warn} hóa đơn cần lưu ý`].filter(Boolean).join(', ') : '';
    send({ type: 'log', level: 'ok', text: `Đã lưu file Excel bảng kê (${book.length} sheet)` });
    if (flags) send({ type: 'log', text: `Có ${flags} – xem lý do trong sheet "Kiểm tra rủi ro HĐ"` });
    else if (risk) send({ type: 'log', level: 'ok', text: 'Kiểm tra rủi ro: tất cả hóa đơn hợp lệ' });
    for (const note of book.notes || []) send({ type: 'log', level: 'warn', text: note });
    saved++;
  }
  // Offline MISA/Tendoo warehouse export. Unmatched goods keep the invoice name
  // and use THIẾU MÃ, so the user can correct the import before submitting it.
  if(sheets.tendoo&&formats.excel&&!stopFlag&&!res.stopped){
    try{
      if(!tendoo?.products?.length||!tendoo?.template?.headers?.length)
        throw new Error('Thiếu danh mục sản phẩm hoặc mẫu nhập kho tích hợp.');
      const purchases=rows.filter(r=>r.kind==='purchase');
      if(!purchases.length)throw new Error('Không có hóa đơn mua vào trong khoảng ngày này.');
      const skuLinks={...(tendoo.links||{})};
      const unknown=TendooImport.missing(purchases,details,tendoo.products,skuLinks);
      if(unknown.length){
        send({type:'log',level:'warn',text:'Có '+unknown.length+
          ' tên hàng chưa khớp danh mục. Có thể bỏ qua để Excel ghi THIẾU MÃ.'});
        const match=await linkSku(unknown);
        if(match?.cancel)throw new Error('Đã hủy xuất nhập kho.');
        Object.assign(skuLinks,match?.mapping||{});
      }
      const packageFile=TendooImport.makePackage(purchases,details,tendoo.products,
        tendoo.template,skuLinks,tendoo.settings||{});
      const platform=tendoo.template.platform==='misa'?'MISA':'Tendoo';
      const bookFiles=await Zip.readZip(packageFile.zip);
      let booksSaved=0;
      for(const [name,data] of Object.entries(bookFiles)){
       if(!/\.xlsx$/i.test(name))continue;
       await save(data,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        dir+'/nhap_hang/'+name);
       booksSaved++;saved++;
      }
      if(!booksSaved)throw Error('Không có file Excel nhập kho hợp lệ.');
      if(platform==='MISA'&&packageFile.lastIssued)
        await chrome.storage.local.set({autotax_misa_last_document_v1:packageFile.lastIssued});
      send({type:'log',level:'ok',text:platform+': đã lưu '+booksSaved+
        ' file Excel nhập kho riêng lẻ vào nhap_hang/.'});
      if(packageFile.missing)send({type:'log',level:'warn',text:
        packageFile.missing+' tên hàng chưa khớp: đã giữ tên và ghi THIẾU MÃ trong file.'});
      if(packageFile.skipped)send({type:'log',level:'warn',text:
        packageFile.skipped+' hóa đơn không có chi tiết hàng, chưa xuất nhập kho.'});
    }catch(e){errors++;send({type:'log',level:'warn',
      text:'Không tạo được file nhập kho: '+e.message})}
  }
  const zipResult=await window.NativeZipBatch.finish();
  if(downloadedInZip.size)
   await updateInvoiceHistory([...downloadedInZip.values()],profile.mst,'downloaded',formatsInZip);
  send({type:'log',level:'ok',text:(zipResult.archive?'Đã lưu 1 ZIP: ':'Đã lưu Excel độc lập: ')+zipResult.name+
    (zipResult.archive?' ('+zipResult.count+' tệp, phân nhóm theo MST và định dạng).':' (không nén).')});
  send({ type: 'done', total: rows.length, saved:zipResult.count, errors, stopped: stopFlag || res.stopped, dir:window.AutoTaxDownloadFolder?.label||'' });
}

// The job runs in the GDT page's content script, independent of sidepanel life.
// Keep the GDT tab open during downloads; reloading it will terminate the job.
const jobPorts=new Set(),pendingSku=new Map(),jobEvents=[];
function sendJob(event){
  if(event.type==='progress'||event.type==='status'){
    for(let i=jobEvents.length-1;i>=0;i--)
      if(jobEvents[i].type===event.type)jobEvents.splice(i,1);
  }
  jobEvents.push(event);
  if(jobEvents.length>250)jobEvents.splice(0,jobEvents.length-250);
  for(const port of [...jobPorts]){
    try{port.postMessage(event)}catch{jobPorts.delete(port)}
  }
}
function finishSkuMapping(msg){
  const task=pendingSku.get(msg.requestId);
  if(!task)return false;
  clearTimeout(task.timeout);pendingSku.delete(msg.requestId);
  task.resolve(msg);return true;
}
function linkSku(names){
  if(!jobPorts.size)return Promise.resolve({mapping:{}});
  return new Promise(resolve=>{
    const requestId='tendoo-map-'+Date.now()+'-'+Math.random().toString(36).slice(2,8);
    const timeout=setTimeout(()=>{
      pendingSku.delete(requestId);resolve({mapping:{}});
      sendJob({type:'log',level:'warn',text:'Hết thời gian ánh xạ; tiếp tục xuất với mã THIẾU MÃ.'});
    },900000);
    pendingSku.set(requestId,{resolve,timeout,keepTab:false});
    sendJob({type:'tendoo-map-request',requestId,names});
  });
}
// Native in-extension transport: same original runJob and messages,
 // but all requests now run inside Chrome Side Panel via Supabase GDT gateway.
 // Never looks for, injects into or requires a hoadondientu browser tab.
 async function ask(msg){
  if(msg?.type==='info')return {...await window.DemoNativeAuth.info(),busy};
  if(msg?.type==='stop'){stopFlag=true;return {ok:true}}
  if(msg?.type==='tendoo-map-response')
   return {ok:finishSkuMapping(msg)};
  return {error:'Lệnh không được hỗ trợ.'};
 }
 function createJobPort(onMessage){
  const receiver={postMessage(event){onMessage(event)}};
  jobPorts.add(receiver);
  function dispatch(msg){
   if(msg?.type==='attach'){
    for(const event of jobEvents){
     if(event.type==='tendoo-map-request'&&!pendingSku.has(event.requestId))continue;
     receiver.postMessage(event);
    }
    return;
   }
   if(msg?.type==='tendoo-mapping-tab-open'){
    const task=pendingSku.get(msg.requestId);if(task)task.keepTab=true;
    return;
   }
   if(msg?.type==='tendoo-map-response'){
    finishSkuMapping(msg);return;
   }
   if(msg?.type!=='run')return;
   if(busy)return sendJob({type:'log',level:'warn',
    text:'Đang có tác vụ chạy. Hãy đợi hoặc bấm Dừng.'});
   busy=true;stopFlag=false;jobEvents.length=0;
   sendJob({type:'run-started'});
   Promise.resolve().then(()=>runJob(msg,sendJob,linkSku))
    .catch(e=>sendJob({type:'error',text:e.message||String(e)}))
    .finally(()=>{busy=false;sendJob({type:'idle'})});
  }
  return {
   postMessage:dispatch,
   disconnect:()=>{
    jobPorts.delete(receiver);
    if(!jobPorts.size){
     for(const [id,task] of pendingSku){
      if(task.keepTab)continue;
      clearTimeout(task.timeout);pendingSku.delete(id);task.resolve({mapping:{}});
     }
    }
   }
  };
 }
 window.DemoNative=Object.freeze({ask,createJobPort,isBusy:()=>busy});
