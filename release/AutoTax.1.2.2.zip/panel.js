import { createRangePicker } from './datepicker.js';

const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const toVN = (s) => s.split('-').reverse().join('/'); // yyyy-mm-dd -> dd/mm/yyyy
// DEMO native has no hoadondientu tab requirement: keep the original
// panel layout, selections and job semantics; only transport is local.
let tabId = 1;
let connected = false;
let portalMst = '';
let configuredMsts = [];
let profilesLoaded = false;
const normalizeMst = value => String(value || '').replace(/\D/g, '');
const profileMatches = () => connected && !!portalMst &&
 (globalThis.License?.getState?.()?.mode==='invoice' ||
   (profilesLoaded && configuredMsts.includes(portalMst)));
let busy = false;
let stopped = false;

async function findTab(){ return 1; }
const ask = (msg) => window.DemoNative.ask(msg);

// Nhật ký nằm dưới các lựa chọn: dòng đầu tiên thì cuộn xuống, sau đó bám cuối trang
// trừ khi người dùng đã cuộn lên xem chỗ khác
const page = document.documentElement;
let followLog = true;
addEventListener('scroll', () => { followLog = innerHeight + scrollY >= page.scrollHeight - 40; }, { passive: true });
// Batch scroll measurements into one animation frame during large invoice scans.
// Synchronous scrollHeight reads on each log append previously forced layouts.
let logScrollFrame = 0;
function scheduleLogScroll() {
  if (logScrollFrame) return;
  logScrollFrame = requestAnimationFrame(() => {
    logScrollFrame = 0;
    const box = $('log');
    if (box) box.scrollTop = box.scrollHeight;
    if (followLog && !document.body.classList.contains('autotax-scanning'))
      window.scrollTo(0, page.scrollHeight);
  });
}
// Theo thứ tự thời gian (1 = việc đầu tiên), dòng mới ở cuối và khung nhật ký tự cuộn tới dòng mới
function log(text, level = '') {
  const box = $('log');
  if (box.lastElementChild?.textContent === text) return box.lastElementChild;
  if (!box.firstElementChild) followLog = true;
  const li = document.createElement('li'); li.textContent = text; li.className = level; box.append(li);
  // Cap hidden legacy log DOM too: a long scan must not freeze the side panel.
  while(box.children.length>200)box.firstElementChild.remove();
  // The existing log remains intact for "Tiếp tục tra cứu"; only the
  // dedicated terminal is capped at ten visible progress entries.
  addScanConsoleLine(text,level);
  scheduleLogScroll();
  return li;
}
let connErr = null;

let scanConsoleLine=0,scanQuotaInFlight=false,scanQuotaLast=0,scanQuotaTimer=null;
let scanScrollFrame=0;
function scheduleScanScroll() {
 if(scanScrollFrame)return;
 scanScrollFrame=requestAnimationFrame(()=>{
  scanScrollFrame=0;
  const scroll=$('autotaxConsoleLines')?.parentElement;
  if(scroll&&scanShown)scroll.scrollTop=scroll.scrollHeight;
 });
}
let scanFinished=false,scanShown=false,scanSessionActive=false,scanEpoch=0;
let scanLastStatus='',scanLastStatusAt=0;
function appendScanStatus(text){
 if(!scanShown||!scanSessionActive)return;
 text=String(text||'').trim();
 if(!text||text===scanLastStatus)return;
 const now=Date.now(),box=$('autotaxConsoleLines'),last=box?.lastElementChild;
 if(last?.dataset.kind==='status'&&now-scanLastStatusAt<850){
  last.lastElementChild.textContent=text;
 }else{
  addScanConsoleLine(text,'system');
  if(box?.lastElementChild)box.lastElementChild.dataset.kind='status';
 }
 scanLastStatus=text;scanLastStatusAt=now;
}
function addScanConsoleLine(text,level=''){
 if(!scanSessionActive)return;
 const box=$('autotaxConsoleLines');if(!box)return;
 const line=document.createElement('div');
 line.className='autotax-console-line '+(level||'');
 const count=document.createElement('span');
 count.className='autotax-console-number';
 count.textContent=String(++scanConsoleLine).padStart(2,'0');
 const content=document.createElement('span');content.textContent=String(text||'');
 line.append(count,content);box.append(line);
 while(box.children.length>20)box.firstElementChild.remove();
 $('autotaxConsoleLineCount').textContent=box.children.length+' / 20';
 scheduleScanScroll();
}
const scanNum=v=>{
 const n=Number(v);return Number.isFinite(n)&&n>0?Math.floor(n):0;
};
function updateScanQuota(state=globalThis.License?.getState?.()){
 if(!state||!$('autotaxScanQuotaValue'))return;
 const inv=state.packages?.invoice||{},mst=state.packages?.mst||{};
 const mode=state.mode==='invoice'?'invoice':'mst';
 const ownInv=scanNum(inv.remaining),groupInv=scanNum(state.team_invoice_spendable_remaining);
 const purchased=scanNum(inv.purchased)+scanNum(state.team_invoice_purchased);
 const activeMsts=scanNum(mst.active_quantity)+scanNum(state.team_mst_count);
 $('autotaxScanQuotaValue').textContent=
  (ownInv+groupInv).toLocaleString('vi-VN')+' / '+purchased.toLocaleString('vi-VN');
 $('autotaxScanQuotaDetails').textContent='Cá nhân: '+ownInv.toLocaleString('vi-VN')+
  ' · Nhóm: '+groupInv.toLocaleString('vi-VN');
 $('autotaxScanMstCount').textContent=activeMsts.toLocaleString('vi-VN')+' MST';
 $('autotaxScanMode').textContent=mode==='invoice'?'Đang sử dụng gói Số tờ':'Đang sử dụng gói MST';
 $('autotaxScanQuotaLabel').textContent=mode==='invoice'?
  'Số tờ đang dùng · Còn lại / Tổng đã mua':'Hạn mức Số tờ · Còn lại / Tổng đã mua';
}
async function refreshScanQuota(force=false){
 if((!scanShown&&!force)||scanQuotaInFlight||!globalThis.License?.refreshQuota)return;
 if(!force&&Date.now()-scanQuotaLast<5000)return;
 const epoch=scanEpoch;
 scanQuotaInFlight=true;scanQuotaLast=Date.now();
 try{
  const state=await globalThis.License.refreshQuota();
  if(epoch===scanEpoch)updateScanQuota(state);
 }catch(error){console.warn('Chưa cập nhật được số tờ trực tiếp:',error.message)}
 finally{scanQuotaInFlight=false}
}
function setScanState(value,label){
 const badge=$('autotaxScanState');
 const titles={RUNNING:'Đang chạy',STOPPING:'Đang dừng',STOPPED:'Đã dừng',DONE:'Hoàn tất',ERROR:'Có lỗi',IDLE:'Sẵn sàng'};
 badge.textContent=titles[value]||value;
 badge.classList.toggle('is-done',value==='DONE');
 badge.classList.toggle('is-running',value==='RUNNING');
 badge.classList.toggle('is-stopping',value==='STOPPING');
 if(label)$('autotaxScanProgressText').textContent=label;
}
function beginScanScreen(){
 scanEpoch++;scanShown=true;scanSessionActive=true;scanFinished=false;scanConsoleLine=0;scanLastStatus='';scanLastStatusAt=0;
 $('autotaxConsoleLines').replaceChildren();
 $('autotaxConsoleLineCount').textContent='0 / 20';
 $('autotaxScanGreeting').hidden=true;
 const scanButton=$('autotaxScanStop');
 scanButton.hidden=false;scanButton.disabled=false;
 scanButton.dataset.mode='stop';scanButton.textContent='Dừng';
 $('autotaxScanProgressBar').style.width='0%';
 $('autotaxScanMst').textContent='MST '+(portalMst||'đang kết nối')+
  ' · '+($('sumRange').textContent||'');
 $('autotaxScanScreen').hidden=false;
 document.body.classList.add('autotax-scanning');
 $('autotaxConsoleReopen').hidden=false;
 setScanState('RUNNING','Đang khởi tạo phiên quét…');
 // Quota is already validated by the export backend. No extra background
 // quota polling is needed while scanning; reserve space for progress output.
 if(scanQuotaTimer){clearInterval(scanQuotaTimer);scanQuotaTimer=null}
 log('> autotax scan --mst='+portalMst+' --date="'+$('sumRange').textContent+'"','system');
 appendScanStatus('Đang khởi tạo phiên quét…');
}
function endScanScreen(result){
 scanFinished=true;
 if(scanQuotaTimer){clearInterval(scanQuotaTimer);scanQuotaTimer=null}
 const stoppedNow=!!result?.stopped||stopped;
 const total=scanNum(result?.total),saved=scanNum(result?.saved),errors=scanNum(result?.errors);
 setScanState(stoppedNow?'STOPPED':'DONE',
  stoppedNow?'Đã dừng. Dữ liệu tải được vẫn được lưu.':'Đã hoàn tất phiên quét.');
 $('autotaxScanStop').hidden=false;
 {const b=$('autotaxScanStop');b.dataset.mode='back';b.textContent='Quay lại';b.disabled=false;}
 $('autotaxScanProgressBar').style.width=stoppedNow?
  $('autotaxScanProgressBar').style.width:'100%';
 if(!stoppedNow){
  $('autotaxScanGreetingDetails').textContent=
   'Đã xử lý '+total.toLocaleString('vi-VN')+' hóa đơn, lưu '+
    saved.toLocaleString('vi-VN')+' tệp'+(errors?' · '+errors+' lỗi.':'.');
  $('autotaxScanGreeting').hidden=false;
 }
 addScanConsoleLine(stoppedNow?'Đã dừng. Đã lưu phần tải thành công.':'Đã hoàn tất phiên quét.','system');
}
function closeScanScreen(){
 scanShown=false;scanEpoch++;
 const b=$('autotaxScanStop');b.dataset.mode='stop';b.textContent='Dừng';
 $('autotaxScanScreen').hidden=true;
 document.body.classList.remove('autotax-scanning');
 $('autotaxConsoleReopen').hidden=!busy&&!scanFinished;
 if(scanQuotaTimer){clearInterval(scanQuotaTimer);scanQuotaTimer=null}
 window.scrollTo(0,0);
}
$('autotaxScanContinue').addEventListener('click',closeScanScreen);
$('autotaxConsoleReopen').addEventListener('click',()=>{
 scanShown=true;
 $('autotaxScanScreen').hidden=false;
 document.body.classList.add('autotax-scanning');
 // Resume the same in-memory progress output without restarting any task.
});
$('autotaxScanStop').addEventListener('click',()=>{
 const button=$('autotaxScanStop');
 if(button.dataset.mode==='back'){closeScanScreen();return;}
 if(!busy){closeScanScreen();return;}
 stopped=true;
 button.dataset.mode='back';button.textContent='Quay lại';button.disabled=false;
 setScanState('STOPPING','Đang dừng phiên quét an toàn…');
 appendScanStatus('Đã yêu cầu dừng, đang lưu các tệp hoàn tất.');
 if(tabId)void ask({type:'stop'}).catch(e=>log('Không dừng được: '+e.message,'error'));
});
document.addEventListener('autotax-license-change',event=>{
 if(scanShown)updateScanQuota(event.detail?.license);
});

// Các lựa chọn Sheet luôn hiển thị để người dùng tự quyết định xuất biểu mẫu nào.
// Đặc biệt không tự tắt Bảng kê HĐKD khi đổi hồ sơ MST hoặc mất kết nối.
function syncHousehold() {
  summarize();
}

function setConnected(on, info = {}) {
  connected = on;
  portalMst = on ? normalizeMst(info.mst) : '';
  syncHousehold(on ? info : {});
  // getSessionInfo() only marks ready when the GDT JWT is valid.
  globalThis.AutoTaxGdtProfile=on?
   {mst:normalizeMst(info.mst),company:String(info.company||'').trim()}:null;
  if(on&&info.company){
   Promise.resolve().then(()=>globalThis.License?.autoNameFromGdt?.(
    globalThis.AutoTaxGdtProfile)).catch(()=>{});
  }
  const name = on ? [info.mst, info.company].filter(Boolean).join(' – ') : '';
  $('company').hidden = !name; $('company').textContent = name; $('company').title = name;
  $('noCompany').hidden = !!name;
  $('session').className = `badge ${on ? 'on' : 'off'}`;
  $('session').textContent = on ? 'Đã kết nối' : 'Chưa kết nối – hãy đăng nhập';
  syncRun();
}

async function init() {
  tabId = await findTab();
  if (!tabId) { setConnected(false); return; }
  let info;
  try { info = await ask({ type: 'info' }); } catch {
    // Tab mở trước khi cài/tải lại extension → chưa có content script
    setConnected(false);
    connErr = log('Hãy đăng nhập cổng Thuế trong khung MST của Add-on.', 'warn');
    tabId = null; return;
  }
  connErr?.remove(); connErr = null;
  if (info.error) log(info.error, 'error');
  setConnected(!!info.ready, info);
  setBusy(!!info.busy);
  if(info.busy)ensureJobPort().postMessage({type:'attach'});
}

// Khoảng chọn nhanh
function presets() {
  const now = new Date(), y = now.getFullYear(), m = now.getMonth(), q = Math.floor(m / 3);
  const r = (a, b) => [iso(a), iso(b)];
  return [
    { key: 'thisMonth', label: 'Tháng này', range: r(new Date(y, m, 1), now) },
    { key: 'lastMonth', label: 'Tháng trước', range: r(new Date(y, m - 1, 1), new Date(y, m, 0)) },
    { key: 'thisQuarter', label: 'Quý này', range: r(new Date(y, q * 3, 1), now) },
    { key: 'lastQuarter', label: 'Quý trước', range: r(new Date(y, (q - 1) * 3, 1), new Date(y, q * 3, 0)) },
    { key: 'thisYear', label: 'Cả năm', range: r(new Date(y, 0, 1), now) },
  ];
}
let activePreset = null;
function preset(kind) {
  const p = presets().find((x) => x.key === kind);
  if (!p) return;
  [$('from').value, $('to').value] = p.range;
  activePreset = kind; renderPresets();
  checkRange();
  picker?.refresh(true);
}
function renderPresets() {
  $('presets').replaceChildren(...presets().map((p) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip' + (p.key === activePreset ? ' active' : ''); b.textContent = p.label;
    b.title = `${toVN(p.range[0])} – ${toVN(p.range[1])}`;
    b.setAttribute('aria-pressed', String(p.key === activePreset));
    b.addEventListener('click', () => { preset(p.key); picker?.close(); });
    return b;
  }));
}

// Khoảng ngày người dùng chọn được chia thành các đợt tra cứu ở tầng API.
const fullDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v || '') && +v.slice(0, 4) >= 2000;
const limits = () => ({ min: '2018-01-01', max: iso(new Date()) });
function maxTo(_from) { return limits().max; }
function rangeError() {
  const from = $('from').value, to = $('to').value;
  if (!fullDate(from) || !fullDate(to)) return 'Hãy chọn Từ ngày và Đến ngày';
  if (to > limits().max) return 'Đến ngày không được sau hôm nay';
  if (from > to) return 'Từ ngày không được sau Đến ngày';
  return null;
}
function checkRange() {
  const err = rangeError();
  $('rangeHint').textContent = err || '';
  $('rangeHint').classList.toggle('error', !!err);
  $('toText').classList.toggle('invalid', !!err);
  summarize();
  return !err;
}
function clampTo() {
  const from = $('from').value, to = $('to').value;
  if (!fullDate(from)) return;
  const max = maxTo(from), today = iso(new Date());
  if (!fullDate(to) || to < from || to > max) { $('to').value = today >= from && today <= max ? today : max; picker?.refresh(); }
}
$('from').addEventListener('input', () => { activePreset = null; renderPresets(); checkRange(); });
$('from').addEventListener('change', () => { clampTo(); checkRange(); });
$('to').addEventListener('input', () => { activePreset = null; renderPresets(); checkRange(); });

const checked = (name) => name==='form'?['hddt','mtt']:[...document.querySelectorAll(`input[name=${name}]:checked`)].map((i) => i.value);
function formats() {
  const f = Object.fromEntries(['excel', 'xml', 'pdf', 'html'].map((k) => [k, checked('fmt').includes(k)]));
  // Chi tiết sản phẩm là sheet cố định của Excel → luôn tải chi tiết từng hóa đơn khi chọn Excel
  f.lines = f.excel;
  return f;
}
const SHEETS = ['risk', 'seller', 'adjust', 'reduction', 'hdkd', 'gtgt', 'tendoo'];
// All supplemental Excel sheets are on by default. Stock-file export requires
// an existing product catalog; when missing it is skipped rather than blocking search.
const sheets = () => Object.fromEntries(SHEETS.map(k => [k,
  k==='tendoo'?!!$('tendooSyncCheck').checked&&tendooReady()&&!!document.querySelector('input[name="fmt"][value="excel"]')?.checked:true]));

/* Stock import templates are bundled, only the product catalog is uploaded. */
let stockPlatform='tendoo',tendooCatalog=null;
let tendooTemplate=TendooImport.builtinTemplate(stockPlatform);
let tendooMappingRequest=null,tendooPendingNames=[],tendooSavedLinks={};
const TENDOO_LINKS_KEY='autotax_tendoo_sku_links_v1';
const STOCK_SETTINGS_KEY='autotax_stock_import_settings_v1';
const STOCK_EXPORT_KEY='autotax_stock_export_opt_in_v1';
const SKU_SYNC_URL='https://ucqqjdsoyvvaxswzbhaw.supabase.co/rest/v1/addon_user_sku_mappings';
const SKU_SYNC_APIKEY='sb_publishable_7zUjUap6EkHJZ0Gp12vesw_UY-yB7jJ';
let skuSyncUserId=null,skuSyncAccessToken=null,stockLoadSeq=0,stockFilename='';
const stockCache=globalThis.AutoTaxStockCatalog;
async function restoreStockExportOption(){
 const id=skuSyncUserId||'anonymous';
 try{
  const stored=await chrome.storage.local.get(STOCK_EXPORT_KEY);
  if(id!==(skuSyncUserId||'anonymous'))return;
  $('tendooSyncCheck').checked=!!stored[STOCK_EXPORT_KEY]?.[id];
  updateTendooUi();summarize();
 }catch(error){console.warn('Chưa đọc được lựa chọn nhập kho:',error.message)}
}
async function saveStockExportOption(){
 const id=skuSyncUserId||'anonymous';
 try{
  const data=await chrome.storage.local.get(STOCK_EXPORT_KEY);
  const state={...(data[STOCK_EXPORT_KEY]||{})};
  state[id]=$('tendooSyncCheck').checked;
  await chrome.storage.local.set({[STOCK_EXPORT_KEY]:state});
 }catch(error){console.warn('Chưa lưu được lựa chọn nhập kho:',error.message)}
}
async function restoreStockCatalog(){
 const seq=++stockLoadSeq,user=skuSyncUserId,platform=stockPlatform,token=skuSyncAccessToken;
 tendooCatalog=null;tendooSavedLinks={};stockFilename='';
 updateTendooUi();
 if(!user)return;
 const result=await stockCache.restore(user,platform,token);
 if(seq!==stockLoadSeq||user!==skuSyncUserId||platform!==stockPlatform)return;
 if(result.catalog){
  tendooCatalog=result.catalog.products;stockFilename=result.catalog.filename||'';
  await loadTendooLinks();
  if(result.warning)log('Danh mục cục bộ đã tải; đồng bộ online: '+result.warning,'warn');
  updateTendooUi();
 }else updateTendooUi();
}
async function replaceStockCatalog(file){
 if(!file)return;
 const user=skuSyncUserId,platform=stockPlatform,token=skuSyncAccessToken;
 if(!user)throw Error('Hãy đăng nhập AutoTax trước khi lưu danh mục hàng hóa.');
 const parsed=await TendooImport.catalog(file,platform);
 if(user!==skuSyncUserId||platform!==stockPlatform)throw Error('Tài khoản hoặc nền tảng đã thay đổi, hãy tải file lại.');
 const payload=stockCache.makePayload(file.name,parsed);
 await stockCache.saveLocal(user,platform,payload);
 tendooCatalog=parsed;stockFilename=payload.filename;
 await loadTendooLinks();
 updateTendooUi();
 try{
  const synced=await stockCache.saveCloud(user,platform,payload,token);
  return {count:parsed.length,synced};
 }catch(error){
  log('File mới đã lưu cục bộ; chưa đồng bộ online: '+error.message,'warn');
  return {count:parsed.length,synced:false};
 }
}
const skuStorageKey=()=>skuSyncUserId+':'+tendooCatalogKey();
const skuSyncHeaders=()=>({
 apikey:SKU_SYNC_APIKEY,Authorization:'Bearer '+skuSyncAccessToken,
 'Content-Type':'application/json'
});
function tendooCatalogKey(){
  if(!tendooCatalog?.length)return '';
  let hash=2166136261;
  for(const product of tendooCatalog){
    const value=product.sku+'|'+product.name+'\n';
    for(let i=0;i<value.length;i++)hash=Math.imul(hash^value.charCodeAt(i),16777619)>>>0;
  }
  return stockPlatform+'-catalog-'+tendooCatalog.length+'-'+hash.toString(16);
}
async function loadTendooLinks(){
 tendooSavedLinks={};
 if(!tendooCatalog?.length)return;
 const data=(await chrome.storage.local.get(TENDOO_LINKS_KEY))[TENDOO_LINKS_KEY]||{};
 const known=new Set(tendooCatalog.map(p=>p.sku));
 tendooSavedLinks=Object.fromEntries(Object.entries(data[skuStorageKey()]||{})
  .filter(([name,sku])=>name&&known.has(sku)));
 if(skuSyncUserId&&skuSyncAccessToken){
  try{
   const query=new URLSearchParams({select:'product_key,sku',
    user_id:'eq.'+skuSyncUserId,platform:'eq.'+stockPlatform,
    catalog_key:'eq.'+tendooCatalogKey(),limit:'1000'});
   const response=await fetch(SKU_SYNC_URL+'?'+query,{headers:skuSyncHeaders()});
   if(!response.ok)throw Error('HTTP '+response.status);
   for(const item of await response.json()){
    if(item.product_key&&known.has(item.sku))tendooSavedLinks[item.product_key]=item.sku;
   }
  }catch(error){log('Đang dùng liên kết SKU cục bộ: '+error.message,'warn')}
 }
}
async function keepTendooLinks(mapping){
 const known=new Set((tendooCatalog||[]).map(p=>p.sku));
 const accepted=Object.fromEntries(Object.entries(mapping||{}).filter(([k,v])=>k&&known.has(v)));
 if(!Object.keys(accepted).length)return;
 const data=(await chrome.storage.local.get(TENDOO_LINKS_KEY))[TENDOO_LINKS_KEY]||{};
 tendooSavedLinks={...tendooSavedLinks,...accepted};
 data[skuStorageKey()]=tendooSavedLinks;
 await chrome.storage.local.set({[TENDOO_LINKS_KEY]:data});
 if(skuSyncUserId&&skuSyncAccessToken){
  const body=Object.entries(accepted).map(([product_key,sku])=>({
   user_id:skuSyncUserId,platform:stockPlatform,catalog_key:tendooCatalogKey(),
   product_key,sku,updated_at:new Date().toISOString()
  }));
  try{
   const response=await fetch(SKU_SYNC_URL+'?on_conflict=user_id,platform,catalog_key,product_key',{
    method:'POST',headers:{...skuSyncHeaders(),Prefer:'resolution=merge-duplicates,return=minimal'},
    body:JSON.stringify(body)
   });
   if(!response.ok)throw Error('HTTP '+response.status);
  }catch(error){log('Đã lưu SKU cục bộ nhưng chưa đồng bộ Supabase: '+error.message,'warn')}
 }
 updateTendooUi();
}
const tendooDialog=$('tendooSettingsDialog');
function tendooStatus(message,error=false){
  const el=$('tendooSetupStatus');el.textContent=message;
  el.style.color=error?'#b91c1c':'#166534';
}
const misaSettings=()=>({
  warehouse:$('misaWarehouse').value.trim(),
  lastDocNumber:$('misaLastDoc').value.trim()
});
function stockSettingsValid(){
  if(stockPlatform!=='misa')return true;
  const settings=misaSettings();
  if(!settings.warehouse)return false;
  try{TendooImport.nextDocumentNumber(settings.lastDocNumber,1);return true}
  catch{return false}
}
const tendooReady=()=>Array.isArray(tendooCatalog)&&tendooCatalog.length>0&&
  !!tendooTemplate?.headers?.length&&stockSettingsValid();
function updateTendooUi(){
  $('tendooSummary').hidden=!$('tendooSyncCheck').checked;
  const label=stockPlatform==='misa'?'MISA':'Tendoo';
  $('tendooSummaryText').textContent=tendooReady()?
    label+': '+tendooCatalog.length+' mã hàng · '+Object.keys(tendooSavedLinks).length+
      ' liên kết đã lưu · danh mục '+(stockFilename||'đã ghi nhớ'):
    label+': cần tải '+(stockPlatform==='misa'?'Danh sách hàng hóa':'BC_San_Pham')+
      (stockPlatform==='misa'?' và nhập Mã kho / Mã chứng từ gần nhất.':'.');
  const hasSkuSample=!!tendooCatalog?.length;
  const shortStatus=$('tendooQuickStatus');
  if(shortStatus){
   shortStatus.textContent=hasSkuSample?'Đã có mẫu SKU '+label:'Chưa có mẫu SKU '+label;
   shortStatus.title=$('tendooSummaryText').textContent;
  }
  $('tendooQuickSetup').textContent=hasSkuSample?'Cập nhật mẫu':'Cập nhật file mẫu';
}
function refreshPlatformFields(){
  const misa=stockPlatform==='misa';
  $('misaStockSettings').hidden=!misa;
  $('stockCatalogLabel').textContent=misa?
    '2. Tải Danh sách hàng hóa MISA (.xlsx)':
    '2. Tải báo cáo sản phẩm BC_San_Pham_*.xlsx';
  $('stockTemplateInfo').textContent=misa?
    'MISA eShop: mẫu nhap_khau_hang_hoa (22 cột phiếu nhập kho) tích hợp sẵn.':
    'Tendoo: mẫu nhập kho GTGT (11 cột) tích hợp sẵn.';
  $('stockPlatform').value=stockPlatform;
  tendooTemplate=TendooImport.builtinTemplate(stockPlatform);
  updateTendooUi();
}
function openTendooSettings(){
  refreshPlatformFields();
  if(!tendooDialog.open)tendooDialog.showModal();
  tendooStatus(tendooReady()?
    'Đã đọc '+tendooCatalog.length+' mã hàng, mẫu '+stockPlatform.toUpperCase()+' tích hợp.':
    'Chọn file danh mục sản phẩm, rồi hoàn tất các ô bắt buộc.');
}
async function storeStockSettings(){
  await chrome.storage.local.set({[STOCK_SETTINGS_KEY]:{platform:stockPlatform,...misaSettings()}});
}
$('tendooSyncCheck').addEventListener('change',()=>{
  updateTendooUi();
  // The checkbox opts in to warehouse export. Settings are required only
  // when a product catalog or MISA warehouse/document configuration is missing.
  if($('tendooSyncCheck').checked&&!tendooReady())openTendooSettings();
  void saveStockExportOption();
  summarize();
});
$('tendooConfigureBtn').addEventListener('click',openTendooSettings);
$('tendooQuickSetup').addEventListener('click',openTendooSettings);
$('tendooData365Buy').addEventListener('click',()=>void License.purchaseData365());
$('tendooData365Close').addEventListener('click',()=>License.closeInlinePayment());
document.addEventListener('autotax-data365-active',()=>{
 const payload=tendooCatalog?.length?stockCache.makePayload(stockFilename,tendooCatalog):null;
 if(payload&&skuSyncUserId&&skuSyncAccessToken)
  stockCache.saveCloud(skuSyncUserId,stockPlatform,payload,skuSyncAccessToken)
   .then(()=>tendooStatus('Gói DATA365 đã kích hoạt, danh mục đã đồng bộ lên tài khoản.'))
   .catch(e=>tendooStatus('Đã mua DATA365, đồng bộ file cần thử lại: '+e.message,true));
});
$('stockPlatform').addEventListener('change',()=>{
  stockPlatform=$('stockPlatform').value;
  tendooCatalog=null;tendooSavedLinks={};$('tendooCatalogFile').value='';
  refreshPlatformFields();
  void restoreStockCatalog().then(()=>{
   tendooStatus(tendooCatalog?'Đã khôi phục '+tendooCatalog.length+' mã hàng cục bộ/online.':
     'Hãy tải danh sách hàng hóa '+stockPlatform.toUpperCase()+'.');
  }).catch(e=>tendooStatus(e.message,true));
});
$('tendooCatalogFile').addEventListener('change',async e=>{
  const file=e.target.files?.[0];if(!file)return;
  tendooCatalog=null;updateTendooUi();tendooStatus('Đang đọc danh mục sản phẩm...');
  try{
    const result=await replaceStockCatalog(file);
    tendooStatus('Đã lưu '+result.count+' mã hàng trên máy'+
      (result.synced?' và đồng bộ online.':'. Gói DATA365 mở khóa đồng bộ khi đổi máy.'));
  }catch(err){tendooStatus('Danh mục không hợp lệ: '+err.message,true)}
  updateTendooUi();
});
$('tendooReplaceCatalog').addEventListener('click',()=>$('tendooReplacementFile').click());
$('tendooReplacementFile').addEventListener('change',async event=>{
 const file=event.target.files?.[0];if(!file)return;
 try{
  const result=await replaceStockCatalog(file);
  log('Đã ghi đè file mẫu mới: '+result.count+' mã hàng'+(result.synced?' · đã đồng bộ online':' · lưu trên máy'),'ok');
  if(tendooMappingRequest&&tendooPendingNames.length)
   mapUnknownTendoo({requestId:tendooMappingRequest,names:tendooPendingNames,suppressTab:true});
 }catch(error){log('Không cập nhật được file mẫu: '+error.message,'error')}
 finally{event.target.value=''}
});
for(const id of ['misaWarehouse','misaLastDoc'])$(id).addEventListener('input',updateTendooUi);
$('tendooSettingsApply').addEventListener('click',async()=>{
  if(!tendooReady())return tendooStatus('Thiếu danh mục, mã kho hoặc mã chứng từ gần nhất không hợp lệ.',true);
  try{
    await storeStockSettings();tendooDialog.close();
    log(stockPlatform.toUpperCase()+': đã cấu hình '+tendooCatalog.length+
      ' mã hàng và mẫu nhập kho tích hợp.','ok');
  }catch(e){tendooStatus('Lỗi lưu cấu hình: '+e.message,true)}
});
$('tendooSettingsCancel').addEventListener('click',()=>{
  tendooDialog.close();
  if(!tendooReady()){
   $('tendooSyncCheck').checked=false;
   void saveStockExportOption();
  }
  updateTendooUi();summarize();
});
chrome.storage.local.get([STOCK_SETTINGS_KEY,'autotax_misa_last_document_v1']).then(data=>{
  const old=data[STOCK_SETTINGS_KEY]||{};
  stockPlatform=old.platform==='misa'?'misa':'tendoo';
  $('misaWarehouse').value=old.warehouse||'';
  $('misaLastDoc').value=data.autotax_misa_last_document_v1||old.lastDocNumber||'';
  refreshPlatformFields();
  void restoreStockCatalog().catch(e=>log('Không khôi phục được danh mục: '+e.message,'warn'));
}).catch(()=>{});
async function openTendooMatchTab(){
  if(!tendooMappingRequest||!tendooPendingNames.length)return;
  const sessionKey='autotax-tendoo-request-'+tendooMappingRequest;
  await chrome.storage.session.set({[sessionKey]:{names:tendooPendingNames,
    products:tendooCatalog||[],platform:stockPlatform,portalTabId:tabId}});
  await chrome.tabs.create({url:chrome.runtime.getURL(
    'tendoo-match.html?rid='+encodeURIComponent(tendooMappingRequest)),active:true});
  port?.postMessage({type:'tendoo-mapping-tab-open',requestId:tendooMappingRequest});
}
$('tendooOpenMatchTab').addEventListener('click',()=>{
 openTendooMatchTab().catch(error=>log('Không mở được tab liên kết: '+error.message,'warn'));
});
// Return results from the original standalone SKU matching tab.
chrome.runtime.onMessage.addListener((message,_sender,reply)=>{
 if(message?.type==='demo-native-mapping'){
  finishTendooMapping(message.requestId,message.mapping)
   .then(()=>reply({ok:true}),error=>reply({ok:false,error:error.message}));
  return true;
 }
 if(message?.type==='demo-native-stock-catalog'){
  (async()=>{
   if(message.requestId!==tendooMappingRequest||!skuSyncUserId)
    throw Error('Phiên ánh xạ SKU đã hết hạn hoặc không có tài khoản.');
   const products=message.products;
   if(!Array.isArray(products)||!products.length||products.length>25000||
    products.some(p=>!p||typeof p.sku!=='string'||typeof p.name!=='string'))
    throw Error('File mẫu sản phẩm không hợp lệ.');
   const payload=stockCache.makePayload(message.filename,products);
   await stockCache.saveLocal(skuSyncUserId,stockPlatform,payload);
   tendooCatalog=products;stockFilename=payload.filename;
   await loadTendooLinks();
   updateTendooUi();
   try{await stockCache.saveCloud(skuSyncUserId,stockPlatform,payload,skuSyncAccessToken)}
   catch(e){log('Danh mục đã cập nhật cục bộ, cloud: '+e.message,'warn')}
   if(tendooMappingRequest)mapUnknownTendoo({
    requestId:tendooMappingRequest,names:tendooPendingNames,suppressTab:true
   });
   return {ok:true,count:products.length};
  })().then(reply,e=>reply({ok:false,error:e.message}));
  return true;
 }
 return false;
});
async function finishTendooMapping(requestId,mapping){
  if(!port||requestId!==tendooMappingRequest)throw Error('Phiên liên kết đã kết thúc.');
  if(!mapping||typeof mapping!=='object')throw Error('Dữ liệu liên kết không hợp lệ.');
  const known=new Set((tendooCatalog||[]).map(p=>p.sku));
  const accepted=Object.fromEntries(Object.entries(mapping).filter(([,sku])=>!!sku));
  for(const [key,sku] of Object.entries(accepted)){
    if(!tendooPendingNames.some(entry=>entry.key===key)||!known.has(sku))
      throw Error('Mã sản phẩm không hợp lệ: '+key);
  }
  const skipped=tendooPendingNames.length-Object.keys(accepted).length;
  await keepTendooLinks(accepted);
  port.postMessage({type:'tendoo-map-response',requestId,
    mapping:{...tendooSavedLinks,...accepted}});
  tendooMappingRequest=null;tendooPendingNames=[];
  const dialog=$('tendooMatchDialog');
  if(dialog.open)dialog.close();
  log('Đã ghép '+Object.keys(accepted).length+' sản phẩm; '+
    skipped+' sản phẩm chưa khớp sẽ ghi THIẾU MÃ.','ok');
}
function mapUnknownTendoo(message){
 const requestId=message.requestId,names=message.names||[];
 tendooMappingRequest=requestId;tendooPendingNames=names;
 const box=$('tendooMissingList');box.replaceChildren();
 for(const [index,entry] of names.entries()){
   const row=document.createElement('div');row.className='tendoo-missing-row';

   // Left: original product name read directly from the purchase invoice.
   const original=document.createElement('div');original.className='tendoo-original-product';
   const sourceLabel=document.createElement('span');sourceLabel.className='tendoo-field-label';
   sourceLabel.textContent='Sản phẩm gốc · HĐ mua vào';
   const originalName=document.createElement('strong');originalName.textContent=entry.name;
   original.append(sourceLabel,originalName);

   // Right: a searchable and explicitly selected product from BC_San_Pham.
   const target=document.createElement('div');target.className='tendoo-linked-product';
   const label=document.createElement('label');label.className='tendoo-field-label';
   const searchId='tendoo-product-search-'+index;
   label.htmlFor=searchId;label.textContent='Sản phẩm liên kết · danh mục '+stockPlatform.toUpperCase();
   const search=document.createElement('input');search.type='search';
   search.id=searchId;search.className='tendoo-product-search';
   search.placeholder='Tìm tên sản phẩm hoặc SKU...';search.autocomplete='off';
   search.setAttribute('aria-label','Tìm sản phẩm BC_San_Pham liên kết với '+entry.name);
   const hidden=document.createElement('input');hidden.type='hidden';
   hidden.dataset.key=entry.key;
   const selected=document.createElement('div');selected.className='tendoo-selected-product';
   selected.textContent='Chưa liên kết: sẽ ghi THIẾU MÃ nếu bỏ qua.';
   selected.setAttribute('aria-live','polite');
   const results=document.createElement('div');results.className='tendoo-search-results';
   results.setAttribute('role','listbox');
   results.setAttribute('aria-label','Kết quả tìm sản phẩm cho '+entry.name);
   const showResults=term=>{
     results.replaceChildren();
     const matched=TendooImport.searchCatalog(tendooCatalog||[],term,12);
     if(!matched.length){
       const empty=document.createElement('small');
       empty.textContent='Không tìm thấy sản phẩm. Bỏ qua để xuất với mã THIẾU MÃ.';
       results.append(empty);return;
     }
     for(const product of matched){
       const option=document.createElement('button');option.type='button';
       option.className='tendoo-product-option';
       const productName=document.createElement('strong');productName.textContent=product.name;
       const sku=document.createElement('span');
       sku.textContent='SKU: '+product.sku+(product.unit?' · '+product.unit:'');
       option.append(productName,sku);
       option.addEventListener('click',()=>{
         hidden.value=product.sku;
         search.value=product.name+' · '+product.sku;
         selected.textContent='Đã liên kết: '+product.name+' ('+product.sku+')';
         selected.classList.add('tendoo-selected-valid');
         results.replaceChildren();
       });
       results.append(option);
     }
   };
   search.addEventListener('focus',()=>showResults(search.value));
   search.addEventListener('input',()=>{
     hidden.value='';selected.textContent='Chưa liên kết: sẽ ghi THIẾU MÃ nếu bỏ qua.';
     selected.classList.remove('tendoo-selected-valid');
     showResults(search.value);
   });
   search.addEventListener('keydown',event=>{
     if(event.key==='ArrowDown'){
       const first=results.querySelector('button');
       if(first){event.preventDefault();first.focus()}
     }else if(event.key==='Enter'){
       // Enter inside search selects the first match, not the entire form.
       event.preventDefault();results.querySelector('button')?.click();
     }
   });
   target.append(label,search,hidden,selected,results);
   row.append(original,target);
   box.append(row);
 }
 const dialog=$('tendooMatchDialog');
 if(!dialog.open)dialog.showModal();
 box.querySelector('.tendoo-product-search')?.focus();
  if(!message.suppressTab)openTendooMatchTab().catch(error=>
   log('Không tự mở được tab riêng, có thể liên kết trong popup: '+error.message,'warn'));
}
$('tendooMatchForm').addEventListener('submit',async e=>{
 e.preventDefault();if(!tendooMappingRequest)return;
 const inputs=[...$('tendooMissingList').querySelectorAll('input[type="hidden"][data-key]')];
 const known=new Set((tendooCatalog||[]).map(p=>p.sku)),mapping={};
 for(const input of inputs){
   const sku=input.value.trim();
   if(!sku)continue;
   if(!known.has(sku))return log('Mã SKU không hợp lệ; vui lòng chọn lại.','warn');
   mapping[input.dataset.key]=sku;
 }
 try{await finishTendooMapping(tendooMappingRequest,mapping)}catch(error){log('Không lưu được SKU: '+error.message,'warn')}
 // Popup closed by finishTendooMapping on success.
});
// Hiding the popup must never leave a warehouse ZIP waiting forever.
$('tendooMatchClose').addEventListener('click',async()=>{
 if(!tendooMappingRequest){$('tendooMatchDialog').close();return}
 const mapping={};
 for(const input of $('tendooMissingList').querySelectorAll('input[data-key]')){
   if(input.value)mapping[input.dataset.key]=input.value;
 }
 try{await finishTendooMapping(tendooMappingRequest,mapping)}
 catch(error){log('Không đóng được popup ánh xạ: '+error.message,'warn')}
});
$('tendooMatchCancel').addEventListener('click',()=>{
 if(tendooMappingRequest){
  port?.postMessage({type:'tendoo-map-response',requestId:tendooMappingRequest,cancel:true});
  chrome.storage.session.remove('autotax-tendoo-request-'+tendooMappingRequest).catch(()=>{});
 }
 tendooMappingRequest=null;tendooPendingNames=[];$('tendooMatchDialog').close();
});

// Bỏ Excel thì nhóm Sheet thêm mờ đi, không tính
function syncFormats(e) {
  const box = (v) => document.querySelector(`input[name=fmt][value=${v}]`);
  $('sheetOpts').disabled = !box('excel').checked;
  $('tendooSyncCheck').disabled=!box('excel').checked;
  // Tô ô đang chọn bằng class (không dùng :has() – side panel có bản Chrome không vẽ lại sau cú bấm đầu)
  document.querySelectorAll('input[name=fmt]').forEach((i) => i.closest('.tile').classList.toggle('on', i.checked));
  summarize();
}
document.querySelectorAll('input[name=fmt]').forEach((i) => i.addEventListener('change', syncFormats));
// Tóm tắt lựa chọn ở footer
const LABELS = { hddt: 'HĐ điện tử', mtt: 'HĐ máy tính tiền', purchase: 'Mua vào', sold: 'Bán ra', excel: 'Excel', xml: 'XML', html: 'HTML', pdf: 'PDF' };
const names = (vals) => vals.map((v) => LABELS[v]).join(' + ') || '—';
function summarize() {
  const from = $('from').value, to = $('to').value;
  $('sumRange').textContent = fullDate(from) && fullDate(to) ? `${toVN(from)} – ${toVN(to)}` : '—';
  const kinds = checked('kind');
  $('sumKinds').textContent = names(checked('form')) + ' · ' + names(kinds) + (kinds.length && $('adjOnly').checked ? ' · chỉ HĐ thay thế/điều chỉnh/hủy' : '');
  const extra = checked('fmt').includes('excel') ? checked('sheet').length : 0;
  $('sumFmt').textContent = names(checked('fmt')).replaceAll(' + ', ', ') + (extra ? ` · ${extra} sheet thêm` : '');
}
document.querySelectorAll('input[name=kind], input[name=sheet], #adjOnly').forEach((i) => i.addEventListener('change', summarize));
document.querySelectorAll('input[name=form]').forEach((i) => i.addEventListener('change', checkRange));
$('clearFmt').addEventListener('click', () => {
  document.querySelectorAll('input[name=fmt]').forEach((i) => { i.checked = false; });
  syncFormats();
});

syncFormats();

function guard(btn, fn) {
  btn.addEventListener('click', async (e) => {
    if (btn.dataset.running) return;
    btn.dataset.running = '1';
    try { await fn(e); } finally { delete btn.dataset.running; }
  });
}
$('hideSidepanel').addEventListener('click',async()=>{
  // An unfinished mapping becomes a valid import with THIẾU MÃ when hidden.
  if(tendooMappingRequest&&port){
    const mapping={};
    for(const input of $('tendooMissingList').querySelectorAll('input[data-key]')){
      if(input.value)mapping[input.dataset.key]=input.value;
    }
    try{await finishTendooMapping(tendooMappingRequest,mapping)}
    catch(e){log('Không chuyển được ánh xạ hiện có: '+e.message,'warn')}
  }
  try{
    if(typeof chrome.sidePanel.close!=='function')
      throw Error('Chrome cần phiên bản 141 trở lên để dùng nút Ẩn.');
    const window=await chrome.windows.getCurrent();
    await chrome.sidePanel.close({windowId:window.id});
  }catch(e){log('Không ẩn được sidepanel: '+e.message,'warn')}
});
guard($('reconnect'), async () => {
  const b = $('reconnect');
  b.classList.add('spin');
  $('session').className = 'badge'; $('session').textContent = 'Đang kết nối…';
  try { await init(); } catch (e) { setConnected(false); log(e.message, 'error'); }
  b.classList.remove('spin');
});

// Switching active browser tabs never invalidates the native GDT session.
// Reconnect only when this Add-on's own login/logout state changes.
document.addEventListener('autotax-demo-gdt-state',()=>{
 init().catch(e=>log('Không khôi phục được phiên trong Add-on: '+e.message,'error'));
});

// Bản nội bộ: không gửi thống kê hoặc dữ liệu sử dụng ra ngoài.
$('run').addEventListener('click', run);
$('changeOutputFolder').addEventListener('click',async()=>{
 try{
  const name=await AutoTaxDownloadFolder.change();
  log('Đã chọn lại thư mục lưu: '+name,'ok');
 }catch(error){if(error.name!=='AbortError')log('Không đổi được thư mục: '+error.message,'warn')}
});
$('stop').addEventListener('click', () => { stopped = true; if (tabId) ask({ type: 'stop' }); });

let port=null,portTabId=null;
function ensureJobPort(){
  if(port)return port;
  port=window.DemoNative.createJobPort(onJobMessage);
  portTabId=1;
  return port;
}
function job(msg){
  const current=ensureJobPort();
  setBusy(true);
  current.postMessage(msg);
}
function onJobMessage(m) {
  if(m.type==='mst-name'){
   // Names inferred from invoices are only suggestions; do not mark an
   // unverified value as officially confirmed taxpayer identity.
   if(m.mst&&m.name)log('Tên NNT tham khảo từ hóa đơn '+m.mst+': '+m.name,'ok');
   return;
  }
  if (m.type === 'run-started')setBusy(true);
  if (m.type === 'tendoo-map-request')return mapUnknownTendoo(m);
  if(m.type==='status'){
    if(scanShown)appendScanStatus(m.text);
    else $('status').textContent=m.text;
  }
  if(m.type==='summary'){
    $('bar').max=Math.max(m.total,1);$('bar').value=0;
    if(scanShown)$('autotaxScanProgressBar').style.width='0%';
  }
  if(m.type==='progress'){
    $('bar').max=m.total||1;$('bar').value=m.done;
    const msg='Đang tải chi tiết '+m.done+'/'+m.total+' hóa đơn';
    if(scanShown){
      appendScanStatus(msg);
      $('autotaxScanProgressBar').style.width=
        Math.min(100,Math.round(100*Number(m.done||0)/Math.max(1,Number(m.total||1))))+'%';
    }
  }
  if(m.type==='log'){
    log(m.text,m.level);
    // Each "Lô xác minh" log follows a confirmed quota transaction.
    // One cheap RPC refreshes the displayed balance; the 3.5 s heartbeat
    // covers long scans whose batch notices arrive between refreshes.
    if(/Lô xác minh|TỔNG KẾT PHIÊN QUÉT|Số tờ: .*trừ lượt/i.test(m.text))
      void refreshScanQuota();
  }
  if(m.type==='error'){
    log(m.text,'error');$('status').textContent='Lỗi – xem chi tiết bên dưới';
    if(scanShown)setScanState('ERROR','Lỗi phiên quét — xem nhật ký Console.');
  }
  if(m.type==='done'){
    void updateIssuerPending();
    $('status').textContent=m.stopped?'Đã dừng – đã lưu phần dữ liệu tải được':
      `Hoàn tất. ZIP nằm trong thư mục ${m.dir||'đã chọn'}/`;
    endScanScreen(m);
    log(m.stopped?'Đã dừng quét và lưu các phần hoàn tất.':'Đã hoàn tất xử lý, tệp xuất đã được ghi.',m.stopped?'warn':'ok');
    if(!m.stopped&&!stopped&&m.total)showDone(m);
  }
  if(m.type==='idle'){
    setBusy(false);
    scanSessionActive=false;
    $('autotaxScanStop').hidden=$('autotaxScanStop').dataset.mode!=='back';
    if(scanShown&&!scanFinished)setScanState('IDLE','Phiên quét đã dừng hoặc kết thúc sớm.');
    void refreshScanQuota(true);
  }
}

function showDone(m) {
  $('doneText').textContent = `Đã xử lý ${m.total} hóa đơn, lưu ${m.saved} tệp vào thư mục ${m.dir || 'đã chọn'}/`
    + (m.errors ? ` (${m.errors} hóa đơn lỗi – xem nhật ký).` : '.');
  // Same friendly completion greeting, presented directly inside the
  // full-screen Console. Original dialog remains for users who returned
  // to the normal search screen before scanning finished.
  if(!scanShown&&!$('doneModal').open)$('doneModal').showModal();
}

// Chưa đăng nhập hoặc đang chạy → khóa nút Tìm kiếm
function syncRun() {
  const matched=profileMatches();
  // An unlicensed MST must still let users click Search to see the one-time
  // grant dialog; verification on the server remains mandatory before scanning.
  $('run').disabled = busy || !connected || !licenseAllowed;
  const warning=$('mstGuardMessage');
  const needsProfile=connected && licenseAllowed &&
   globalThis.License?.getState?.()?.mode!=='invoice' && !matched;
  warning.hidden=!needsProfile;
  if(needsProfile){
    $('mstGuardReason').textContent=!profilesLoaded?
      'Chưa tải được danh sách hồ sơ MST. Hãy làm mới gói AutoTax rồi thử lại.':
      'MST đang đăng nhập cổng Thuế ('+(portalMst||'không xác định')+
       ') chưa được cấp quyền. Hãy đăng nhập lại MST và xác nhận Có để cấp phép, hoặc chọn gói phù hợp.';
  }
  $('run').title=!licenseAllowed?'Đăng nhập AutoTax và kích hoạt gói sử dụng':
   !connected?'Hãy đăng nhập cổng Thuế trực tiếp trong Add-on':
   !matched?'Chưa cấu hình MST đang đăng nhập trên cổng Thuế':'';
}

function setBusy(on) {
  busy = on;
  document.body.classList.toggle('busy', on);
  $('stop').hidden = !on;
  $('autotaxScanStop').hidden=!on&&$('autotaxScanStop').dataset.mode!=='back';
  if(on&&$('autotaxScanStop').dataset.mode!=='back')$('autotaxScanStop').disabled=false;
  syncRun();
  $('run').textContent = on ? 'Đang xử lý…' : 'Tìm kiếm';
}

async function run() {
  if (busy) return;
  if (!License.canUse()) { log('Tài khoản AutoTax chưa có quyền sử dụng còn hiệu lực. Hãy đăng nhập/kích hoạt tại mục Quản lý bản quyền.', 'warn'); return; }
  if (!tabId || !connected) return init();
  if (!profileMatches()) {
    try{
      const consent=await License.mstConsentStatus(portalMst);
      if(consent?.should_ask){
        const dialog=$('lic-mst-consent-dialog');
        dialog.querySelector('p').textContent=
          'Có muốn cấp quyền sử dụng MST cho MST: '+portalMst+' không?';
        const yes=await new Promise(resolve=>{
          const accept=$('lic-mst-consent-yes'),deny=$('lic-mst-consent-no');
          const finish=value=>{accept.removeEventListener('click',onYes);deny.removeEventListener('click',onNo);
            dialog.removeEventListener('close',onClose);
            if(dialog.open)dialog.close();resolve(value)};
          const onYes=()=>finish(true),onNo=()=>finish(false),onClose=()=>finish(false);
          accept.addEventListener('click',onYes,{once:true});
          deny.addEventListener('click',onNo,{once:true});
          dialog.addEventListener('close',onClose,{once:true});
          dialog.showModal();
        });
        const recorded=await License.mstConsentDecide(portalMst,yes);
        log(yes&&recorded?.allowed?'MST '+portalMst+' đã được cấp quyền.':
          'MST '+portalMst+' chưa được cấp quyền; lựa chọn được lưu trên tài khoản.',yes?'ok':'warn');
        await License.check();
      }
    }catch(error){log('Chưa ghi nhận được lựa chọn cấp phép MST: '+error.message,'warn')}
    if(!profileMatches()){
      const shown=globalThis.AutoTaxMstGrantDialog?.(portalMst);
      log('MST '+(portalMst||'đang đăng nhập')+
        (shown?' cần cấp quyền trong Thông tin tài khoản.':
          ' chưa được cấp quyền. Hãy mở Thông tin tài khoản để cấu hình lại.'),'warn');
      syncRun();return;
    }
  }
  if (!checkRange()) { $('toText').focus(); return; }
  // Hình thức: hóa đơn điện tử (query, chia tháng) và/hoặc máy tính tiền (sco-query, đoạn 10 ngày + captcha)
  const kinds = checked('kind'), forms = checked('form'), f = formats();
  if (!forms.length) return log('Hãy chọn hình thức hóa đơn (điện tử / máy tính tiền)', 'warn');
  if (!kinds.length) return log('Hãy chọn loại hóa đơn (mua vào / bán ra)', 'warn');
  if (!Object.values(f).some(Boolean)) return log('Hãy chọn ít nhất 1 loại file cần tải', 'warn');
  const options=sheets();
  if(options.tendoo&&!kinds.includes('purchase')){
    options.tendoo=false;log('Không có hóa đơn mua vào, bỏ qua file nhập kho.','warn');
  }
  if($('tendooSyncCheck').checked&&!tendooReady())
   log('Đã tick Nhập kho nhưng chưa có mẫu SKU hoặc cấu hình hợp lệ. Bỏ qua file nhập kho; các định dạng khác vẫn tải.','warn');
  // Ask from the click gesture BEFORE starting any GDT queries.
  // Stored handles are reused while Chrome still grants write permission.
  try{
   const folder=await AutoTaxDownloadFolder.prepare();
   $('status').textContent='Lưu tệp rời vào thư mục: '+folder;
  }catch(error){
   if(error.name!=='AbortError')log('Chưa chọn được thư mục lưu: '+error.message,'warn');
   return;
  }
  const msg = { type: 'run', tuNgay: toVN($('from').value), denNgay: toVN($('to').value),
    kinds, forms, formats: f, sheets: options, adjOnly: $('adjOnly').checked,
    ...(options.tendoo?{tendoo:{products:tendooCatalog,template:tendooTemplate,
      links:tendooSavedLinks,settings:misaSettings()}}:{}) };
  $('log').innerHTML = ''; $('bar').value = 0; $('status').textContent = '';
  stopped = false;
  beginScanScreen();
  job(msg);
}

document.querySelectorAll('input[name=form]').forEach((el) => el.addEventListener('change', checkRange));

const picker = createRangePicker({
  from: $('from'), to: $('to'), fromText: $('fromText'), toText: $('toText'), anchor: $('dateRange'), maxTo, limits,
});
preset('lastMonth');

// Gate the existing invoice workflow using the server-verified license.
let licenseAllowed=false;
function applyLicense(st){licenseAllowed=!!st?.allowed;syncRun()}
document.addEventListener('autotax-license-change',e=>{
 applyLicense(e.detail?.license);
 const sess=e.detail?.session||null,newId=sess?.user?.id||null;
 const userChanged=newId!==skuSyncUserId;
 skuSyncUserId=newId;
 skuSyncAccessToken=sess?.access_token||null;
 if(userChanged){
  void restoreStockExportOption();
  void restoreStockCatalog().catch(error=>log('Không khôi phục được danh mục: '+error.message,'warn'));
 }
});
document.addEventListener('autotax-license-gate',e=>{licenseAllowed=!!e.detail?.allowed;syncRun()});
document.addEventListener('autotax-mst-profiles',e=>{
 configuredMsts=(e.detail?.allowed||[]).map(normalizeMst);
 profilesLoaded=!!e.detail?.userId;
 syncRun();
});

const HISTORY_KEY = 'autotax_invoice_history_v1';
let historyRecords = [];
const historyDate = value => { if(!value) return ''; const d=new Date(value); return Number.isNaN(d.getTime()) ? String(value).slice(0,10) : d.toLocaleDateString('vi-VN'); };
function renderHistory() {
  const q=($('historySearch')?.value||'').trim().toLocaleLowerCase('vi');
  const f=$('historyFilter')?.value||'all';
  const selectedMst=$('historyMst')?.value||'';
  const rows=historyRecords.filter(r=>{
    const text=[r.invoiceNo,r.series,r.template,r.mst,r.sellerTax,r.sellerName,r.buyerTax,r.buyerName].join(' ').toLocaleLowerCase('vi');
    return (!selectedMst||normalizeMst(r.mst)===selectedMst) && (!q||text.includes(q)) && (f==='all'||(f==='searched'&&r.lastSearchedAt)||(f==='downloaded'&&r.downloadedAt)||(f==='notDownloaded'&&!r.downloadedAt));
  }).slice(0,250);
  $('historyCount').textContent=historyRecords.length.toLocaleString('vi-VN');
  let downloadedCount=0,searchedCount=0;
  for(const row of historyRecords){if(row.downloadedAt)downloadedCount++;if(row.lastSearchedAt)searchedCount++}
  $('historySummary').textContent=historyRecords.length?downloadedCount+' đã tải · '+searchedCount+' đã tra cứu':'Chưa có dữ liệu lịch sử';
  const body=$('historyRows'); body.replaceChildren();
  if(!rows.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=4;td.textContent='Không có hóa đơn phù hợp.';tr.append(td);body.append(tr);return}
  const fragment=document.createDocumentFragment();
  for(const r of rows){
    const tr=document.createElement('tr');
    const partner=r.kind==='purchase' ? (r.sellerName||r.sellerTax) : (r.buyerName||r.buyerTax);
    const values=[historyDate(r.date),[r.series,r.invoiceNo].filter(Boolean).join(' / ')||'—',partner||'—',r.downloadedAt?'Đã tải về':'Đã tra cứu'];
    for(let i=0;i<values.length;i++){const td=document.createElement('td');td.textContent=values[i];if(i===3)td.className=r.downloadedAt?'history-done':'history-seen';tr.append(td)}
    fragment.append(tr);
  }
  body.append(fragment);
}
async function loadHistory(){
  const data=await chrome.storage.local.get(HISTORY_KEY);
  historyRecords=Object.values(data[HISTORY_KEY]?.records||{}).sort((a,b)=>(b.lastSearchedAt||b.firstSeenAt||'').localeCompare(a.lastSearchedAt||a.firstSeenAt||''));
  const mstFilter=$('historyMst');
  const previous=mstFilter.value;
  const ids=[...new Set(historyRecords.map(r=>normalizeMst(r.mst)).filter(Boolean))].sort();
  mstFilter.replaceChildren();
  const all=document.createElement('option');all.value='';all.textContent='Tất cả MST';mstFilter.append(all);
  for(const mst of ids){const option=document.createElement('option');option.value=mst;option.textContent=mst;mstFilter.append(option)}
  mstFilter.value=ids.includes(previous)?previous:'';
  renderHistory();
}
let historyInputTimer=null;
$('historySearch')?.addEventListener('input',()=>{
 clearTimeout(historyInputTimer);
 historyInputTimer=setTimeout(renderHistory,130);
});
$('historyFilter')?.addEventListener('change',renderHistory);
$('historyMst')?.addEventListener('change',renderHistory);
$('historyRefresh')?.addEventListener('click',()=>loadHistory().catch(e=>log('Không đọc được lịch sử: '+e.message,'error')));
$('historyExport')?.addEventListener('click',()=>{
  const cols=['mst','kind','form','date','series','invoiceNo','template','sellerTax','sellerName','buyerTax','buyerName','lastSearchedAt','searchedCount','downloadedAt','downloadedFormats'];
  const csv=[cols.join(','),...historyRecords.map(r=>cols.map(k=>'"'+String(Array.isArray(r[k])?r[k].join('|'):(r[k]??'')).replace(/"/g,'""')+'"').join(','))];
  const blob=new Blob(['\uFEFF'+csv.join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='autotax-lich-su-hoa-don.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
// Publisher permissions are declared in the signed Chrome manifest and
// checked silently by the background worker, without extra UI controls.
// Lookup queue is stored only in Chrome's session storage, without invoice
// PDF bytes, and is opened one real supplier portal at a time on user click.
async function updateIssuerPending(){
 const button=$('issuerOpenNext');
 if(!button)return;
 try{
  const r=await chrome.runtime.sendMessage({type:'issuer-queue-count',ownerMst:connected?portalMst:''});
  const n=r?.ok?Number(r.count||0):0;
  button.hidden=n===0||!connected;
  button.textContent='Tiếp tục lấy PDF gốc ('+n+' hóa đơn)';
 }catch{button.hidden=true}
}
$('issuerOpenNext')?.addEventListener('click',async()=>{
 const button=$('issuerOpenNext');button.disabled=true;
 try{
  const res=await chrome.runtime.sendMessage({type:'issuer-open-next',ownerMst:portalMst});
  if(!res?.ok)throw Error(res?.error||'Không mở được cổng phát hành.');
  log('Đã mở cổng tra cứu PDF gốc cho '+res.invoice+
    '. Nhập mã bảo mật, thực hiện CAPTCHA rồi bấm Tìm PDF trên trang.', 'ok');
  await updateIssuerPending();
 }catch(e){log('Không mở được hóa đơn: '+(e.message||e),'error')}
 finally{button.disabled=false}
});
void updateIssuerPending();

// Publisher-domain access is verified silently by the extension background.
// The user does not need to press a permissions-check button.


// Always default to both HDĐT and MTT on opening the Add-on.
document.querySelectorAll('input[name="form"]').forEach(input=>{input.checked=true});
summarize();checkRange();
// Global Side Panel remains open when a shortcut opens a new tab.
const SAFE_SHORTCUT_URLS=new Set([
 'https://tracuuhoadon.top/k',
 'https://tracuuhoadon.top/baogia/',
 'https://tracuuhoadon.top/'
]);
document.querySelectorAll('a[data-open-tab]').forEach(link=>{
 link.addEventListener('click',async event=>{
  event.preventDefault();
  if(!SAFE_SHORTCUT_URLS.has(link.href)){
   log('Liên kết không thuộc AutoTax.','error');return;
  }
  try{await chrome.tabs.create({url:link.href,active:true})}
  catch(e){log('Không mở được trang Web: '+(e.message||e),'error')}
 });
});
loadHistory().catch(e=>log('Không đọc được lịch sử: '+e.message,'error'));
init().catch((e) => log(e.message, 'error'));
