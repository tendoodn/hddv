/* AutoTax V1.2.2 extension release note, scoped to local Chrome storage.
   No external requests, permissions or tracking. */
(()=>{
 'use strict';
 const key='autotax_release_seen_v122';
 async function init(){
  try{
   const seen=await chrome.storage.local.get(key);
   if(seen?.[key])return;
  }catch(error){console.warn('Không đọc được cờ thông báo AutoTax:',error.message)}
  if(document.getElementById('autotaxReleaseNotice'))return;
  const wrap=document.createElement('aside');wrap.id='autotaxReleaseNotice';
  wrap.setAttribute('role','region');wrap.setAttribute('aria-label','Thông báo phiên bản AutoTax');
  wrap.style.cssText='position:fixed;z-index:9999;bottom:8px;left:8px;right:8px;background:#fff6f7;border:1px solid #e36876;border-radius:12px;padding:12px;box-shadow:0 10px 30px #0003;color:#4b1e2b;font:12px/1.5 system-ui,sans-serif';
  const title=document.createElement('strong');title.textContent='AutoTax V1.2.2 đã cập nhật';
  title.style.cssText='display:block;color:#a20d29;font-size:14px';
  const description=document.createElement('p');description.textContent='Đã đồng bộ Web · Lite · Add-on về một khối, thống nhất đăng nhập, tên file tải, phản hồi giao diện và luồng xử lý. PDF dựng được cải thiện độ nét và trải nghiệm xem.';
  description.style.margin='5px 0 10px';
  const dismiss=document.createElement('button');dismiss.type='button';dismiss.textContent='Đóng thông báo';
  dismiss.style.cssText='background:#bd0e2c;border:0;border-radius:8px;padding:8px 12px;color:white;font-weight:700;cursor:pointer';
  dismiss.addEventListener('click',()=>{void chrome.storage.local.set({[key]:true}).catch(()=>{});wrap.remove()});
  wrap.append(title,description,dismiss);document.body.append(wrap);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>void init());
 else void init();
})();
