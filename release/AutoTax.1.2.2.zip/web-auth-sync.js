(()=>{
'use strict';
const STORE='autotax_license_session_v1';
const SYNC='autotax_auth_sync_v1';
const WEB_SOURCE='autotax-web-auth-v1';
const EXT_SOURCE='autotax-extension-auth-v1';
const origin=location.origin;
const validSession=s=>!!(s&&typeof s==='object'&&typeof s.access_token==='string'&&typeof s.refresh_token==='string'&&s.user?.id);
const cleanSession=s=>validSession(s)?{
 access_token:s.access_token,
 refresh_token:s.refresh_token,
 token_type:s.token_type||'bearer',
 expires_in:Number(s.expires_in||0)||undefined,
 expires_at:Number(s.expires_at||0)||undefined,
 user:s.user
}:null;
async function readState(){
 const data=await chrome.storage.local.get([STORE,SYNC]);
 const stored=cleanSession(data[STORE]);
 const sync=data[SYNC]&&typeof data[SYNC]==='object'?data[SYNC]:null;
 if(sync&&Number(sync.syncedAt)>0){
  return {
   state:sync.state==='signed_in'&&cleanSession(sync.session)?'signed_in':'signed_out',
   session:sync.state==='signed_in'?cleanSession(sync.session):null,
   syncedAt:Number(sync.syncedAt)||0
  };
 }
 return {state:stored?'signed_in':'unknown',session:stored,syncedAt:0};
}
function send(state){
 window.postMessage({source:EXT_SOURCE,type:'state',...state},origin);
}
async function publish(){send(await readState())}
window.addEventListener('message',event=>{
 if(event.source!==window||event.origin!==origin)return;
 const msg=event.data;
 if(!msg||msg.source!==WEB_SOURCE)return;
 if(msg.type==='pull'){void publish();return}
 if(msg.type!=='push')return;
 void (async()=>{
  const incomingAt=Number(msg.syncedAt)||Date.now();
  const current=await readState();
  if(current.syncedAt&&incomingAt<current.syncedAt){send(current);return}
  if(msg.state==='signed_in'){
   const session=cleanSession(msg.session);
   if(!session)return;
   await chrome.storage.local.set({
    [STORE]:session,
    [SYNC]:{state:'signed_in',session,syncedAt:incomingAt}
   });
  }else if(msg.state==='signed_out'){
   await chrome.storage.local.set({
    [STORE]:null,
    [SYNC]:{state:'signed_out',session:null,syncedAt:incomingAt}
   });
  }else return;
  await publish();
 })().catch(()=>{});
});
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area!=='local'||(!changes[STORE]&&!changes[SYNC]))return;
 void publish();
});
void publish();
})();