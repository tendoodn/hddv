/* AutoTax 1.1.20: one archive per run, grouped by MST and format. */
(()=>{
 'use strict';
 let current=null;
 const safe=v=>String(v||'').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,130);
 const fileDate=value=>{
  const raw=String(value||'').trim();
  const iso=/^(\d{4})-(\d{2})-(\d{2})/.exec(raw);
  if(iso)return iso[3]+iso[2]+iso[1];
  const vn=/^(\d{2})\/(\d{2})\/(\d{4})/.exec(raw);
  if(vn)return vn[1]+vn[2]+vn[3];
  const digits=raw.replace(/\D/g,'');
  if(/^\d{8}$/.test(digits)&&/^(19|20)\d{6}$/.test(digits))
   return digits.slice(6,8)+digits.slice(4,6)+digits.slice(0,4);
  return digits||'KhongRoNgay';
 };
 const buffer=async v=>v instanceof Uint8Array?v:v instanceof ArrayBuffer?new Uint8Array(v):
  v instanceof Blob?new Uint8Array(await v.arrayBuffer()):
  ArrayBuffer.isView(v)?new Uint8Array(v.buffer,v.byteOffset,v.byteLength):
  new TextEncoder().encode(String(v??''));
 function begin(mst,alias='',from='',to=''){
  if(current)throw Error('Đang có một đợt tải chưa hoàn tất.');
  const digits=String(mst||'').replace(/\D/g,'');
  if(!/^(?:\d{10}|\d{12}|\d{13})$/.test(digits))throw Error('MST không hợp lệ khi tạo ZIP.');
  current={mst:digits,alias:safe(alias).slice(0,75)||'TenMST',from:String(from||''),to:String(to||''),files:[],bytes:0};
 }
 async function capture(name,data,mime){
  if(!current)throw Error('Chưa khởi tạo ZIP.');
  const raw=String(name||'').replace(/\\/g,'/');
  if(!raw||raw.split('/').includes('..'))throw Error('Tên tệp không hợp lệ.');
  const bytes=await buffer(data);
  if(bytes.byteLength>100*1024*1024)throw Error('Tệp vượt 100 MB.');
  current.bytes+=bytes.byteLength;
  if(current.bytes>350*1024*1024)throw Error('Dữ liệu quá 350 MB. Hãy thu hẹp kỳ xuất.');
  current.files.push({name:raw,data:bytes,mime});
  return raw;
 }
 function assemble(batch){
  // Match web's single download: MST_TenDoanhNghiep.zip, Excel at ZIP root,
  // other formats grouped in normal directories (not nested ZIP archives).
  const outer=[],used=new Set();
  const unique=(folder,value)=>{
   const clean=safe(value)||'Tep';
   let name=folder+clean,number=2;
   const dot=clean.lastIndexOf('.'),stem=dot>=0?clean.slice(0,dot):clean,ext=dot>=0?clean.slice(dot):'';
   while(used.has(name.toLowerCase())){
    name=folder+stem+'_'+number+++ext;
   }
   used.add(name.toLowerCase());return name;
  };
  const compact=s=>String(s||'').replace(/\D/g,'');
  const period=compact(batch.from)+'_'+compact(batch.to);
  let excelCount=0;
  for(const item of batch.files){
   const path=String(item.name||'').replace(/\\/g,'/'),
    pieces=path.split('/').filter(Boolean),leaf=pieces.at(-1)||'file';
   let targetFolder='',targetLeaf=leaf;
   if(/\.xlsx$/i.test(leaf)){
    targetLeaf=excelCount++?
      'Bang_Thong_Ke_'+batch.mst+'_'+period+'_'+excelCount+'.xlsx':
      'Bang_Thong_Ke_'+batch.mst+'_'+period+'.xlsx';
   }else if(/\/nhap_hang\//i.test(path)||/\/nhaphang\//i.test(path)){
    targetFolder='NhapHang/';
   }else if(/\.xml$/i.test(leaf)||/\/XML\//i.test(path)){
    targetFolder='XML/';
   }else if(/\.html?$/i.test(leaf)||/\/HTML\//i.test(path)){
    targetFolder='HTML/';
    if(pieces.length>2)targetLeaf=safe(pieces.at(-2))+'_'+leaf;
   }else if(/\.pdf$/i.test(leaf)||/\/PDF_/i.test(path)){
    targetFolder='PDF/';
   }else targetFolder='';
   outer.push({name:unique(targetFolder,targetLeaf),data:item.data});
  }
  if(!outer.length)throw Error('Không có tệp để lưu ZIP.');
  outer.push({name:'THONG_TIN_NGUON.txt',
   data:new TextEncoder().encode(
     'AutoTax - Gói tải hóa đơn\r\nMST: '+batch.mst+'\r\nKỳ: '+batch.from+' - '+batch.to+
     '\r\nNguồn: https://hoadondientu.gdt.gov.vn/\r\nSố tệp: '+batch.files.length+
     '\r\nXML chỉ được xuất khi người dùng chọn tải XML.')});
  return Zip.writeZip(outer);
 }
 async function finish(){
  if(!current)throw Error('Chưa có đợt tải.');
  const batch=current;current=null;
  // Single Excel output is a plain .xlsx file, not a one-file ZIP.
  // Keep the same trusted directory picker/fallback as all other downloads.
  if(batch.files.length===1&&/\.xlsx$/i.test(batch.files[0].name)){
   const file='Bang_Thong_Ke_'+batch.mst+'_'+fileDate(batch.from)+'_'+fileDate(batch.to)+'.xlsx';
   await AutoTaxDownloadFolder.saveRootFile(file,batch.files[0].data,
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
   return {name:file,count:1,archive:false};
  }
  const file=batch.mst+'_'+fileDate(batch.from)+'_'+fileDate(batch.to)+'.zip';
  await AutoTaxDownloadFolder.saveRootArchive(file,assemble(batch));
  return {name:file,count:batch.files.length,archive:true};
 }
 const cancel=()=>{current=null;};
 window.NativeZipBatch=Object.freeze({begin,capture,finish,cancel,capturing:()=>!!current});
})();